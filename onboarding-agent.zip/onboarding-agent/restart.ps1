# Restart script for onboarding agent with new database schema
Write-Host "=== Onboarding Agent Restart Script ===" -ForegroundColor Cyan

# Step 1: Stop any running Python processes on port 8000
Write-Host "`n[1/4] Stopping server..." -ForegroundColor Yellow
$processes = Get-NetTCPConnection -LocalPort 8000 -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique
if ($processes) {
    foreach ($proc in $processes) {
        Stop-Process -Id $proc -Force -ErrorAction SilentlyContinue
        Write-Host "  Stopped process $proc" -ForegroundColor Green
    }
    Start-Sleep -Seconds 2
} else {
    Write-Host "  No server running on port 8000" -ForegroundColor Gray
}

# Step 2: Delete old database
Write-Host "`n[2/4] Deleting old database..." -ForegroundColor Yellow
if (Test-Path "data/onboarding.db") {
    Remove-Item "data/onboarding.db" -Force
    Write-Host "  Database deleted" -ForegroundColor Green
} else {
    Write-Host "  No database file found" -ForegroundColor Gray
}

# Step 3: Create new database with updated schema
Write-Host "`n[3/4] Creating new database..." -ForegroundColor Yellow
py -m scripts.seed
if ($LASTEXITCODE -eq 0) {
    Write-Host "  Database created successfully" -ForegroundColor Green
} else {
    Write-Host "  Error creating database" -ForegroundColor Red
    exit 1
}

# Step 4: Start server
Write-Host "`n[4/4] Starting server..." -ForegroundColor Yellow
Write-Host "  Server will start at http://localhost:8000" -ForegroundColor Cyan
Write-Host "  API docs available at http://localhost:8000/docs" -ForegroundColor Cyan
Write-Host "`n  Press Ctrl+C to stop the server" -ForegroundColor Gray
Write-Host "========================================`n" -ForegroundColor Cyan

py -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

# Made with Bob
