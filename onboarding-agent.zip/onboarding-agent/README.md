# Employee Onboarding AI Agent

A conversational AI agent ("Bob Assistant") that automates employee onboarding
with **Background Verification (BGV)**, **PMO approval**, **real-time
notifications**, an **FAQ knowledge base**, and **SLA-driven escalation**.

Generated from the high-level presentation and JSON schema for the
Juniper Network Project onboarding process.

---

## What it does — the 10-step workflow

| Step | Description | Where it lives |
|------|-------------|----------------|
| 1–2  | Employee chats with the agent to request the BGV form; agent shares it | `agent/`, `WorkflowOrchestrator.request_form` |
| 3    | Employee submits the filled form | `POST /api/forms/{id}/submit` |
| 4    | Agent validates — missing mandatory fields → returned to employee | `FormService.validate_form` |
| 5    | Validated form submitted to the PMO team | `WorkflowOrchestrator.submit_form` |
| 6    | PMO reviews → reject (notify employee) or approve | `WorkflowOrchestrator.pmo_review` |
| 7    | Approval triggers the BGV team email | `WorkflowOrchestrator._trigger_bgv` |
| 8    | Agent records BGV responses → status updates to Employee + PMO | `WorkflowOrchestrator.record_bgv_update` |
| 9    | FAQ knowledge base answers general onboarding queries | `KnowledgeBaseService` |
| 10   | SLA breach → escalation emails to PMO + BGV, Employee on CC | `SlaService`, scheduler |

---

## Tech stack

- **FastAPI** — REST API + ASGI app
- **SQLAlchemy 2.x** — ORM (SQLite by default; swap `DATABASE_URL` for Postgres/MySQL)
- **APScheduler** — periodic SLA escalation sweep
- **Pydantic v2** — request/response validation
- Rule-based NLU for intent detection (no external LLM required; optional LLM hook included)

---

## Project layout

```
onboarding-agent/
├── app/
│   ├── main.py               FastAPI entry point
│   ├── core/                 config, database, logging, custom enum type
│   ├── models/               ORM entities (from JSON schema), enums, Pydantic schemas
│   ├── services/             form, validation, notification, email, SLA, KB, workflow, scheduler
│   ├── agent/                intent detection + conversational OnboardingAgent
│   └── api/                  chat, onboarding and admin routes
├── data/knowledge_base/      faqs.json — editable FAQ repository
├── frontend/                 demo chat + workflow console (single HTML file)
├── scripts/seed.py           bootstrap PMO/BGV teams + demo employee
├── tests/                    pytest suite (16 tests, all passing)
├── requirements.txt
└── .env.example
```

The ORM models in `app/models/entities.py` map 1:1 to the entities in the
supplied JSON schema: `Employee`, `PMOTeam`, `BackgroundVerificationTeam`,
`OnboardingForm`, `FormField`, `NotificationEvent`, `EscalationEvent`.

---

## Quick start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Configure — set the two prerequisite emails (PMO + BGV)
cp .env.example .env
#   edit .env: PMO_TEAM_EMAIL, BGV_TEAM_EMAIL

# 3. Seed the database (PMO team, BGV team, a demo employee)
python -m scripts.seed

# 4. Run
uvicorn app.main:app --reload
```

Then open:

- **http://localhost:8000/**        — demo chat + workflow console
- **http://localhost:8000/docs**    — interactive API documentation
- **http://localhost:8000/health**  — liveness probe

---

## Configuration (`.env`)

| Variable | Purpose |
|----------|---------|
| `PMO_TEAM_EMAIL` / `BGV_TEAM_EMAIL` | **Prerequisites** — notification recipients |
| `SMTP_*` | Mail server. With `SMTP_ENABLED=false` emails are logged, not sent (good for demos) |
| `SLA_FORM_VALIDATION_MIN` / `SLA_PMO_REVIEW_MIN` / `SLA_BGV_COMPLETION_MIN` | SLA targets (minutes) |
| `SLA_MONITOR_INTERVAL_MIN` | How often the escalation sweep runs |
| `LLM_ENABLED` / `ANTHROPIC_API_KEY` | Optional — route intent detection through an LLM |

> **Note:** SLA timelines are design-only values for exercising the
> escalation logic, as stated in the source presentation.

---

## Key API endpoints

| Method & path | Workflow step |
|---------------|---------------|
| `POST /api/chat` | Conversational entry — steps 1, 8, 9 |
| `POST /api/employees` | Register an employee |
| `POST /api/employees/{id}/form` | Provision a BGV form (steps 1–2) |
| `POST /api/forms/{id}/submit` | Submit + validate (steps 3–5) |
| `POST /api/forms/{id}/pmo-review` | PMO approve/reject (step 6) |
| `POST /api/forms/{id}/bgv-update` | Record BGV response (step 8) |
| `POST /api/admin/run-escalation-sweep` | Manually trigger escalation (step 10) |
| `GET  /api/admin/notifications` | Notification history |

---

## Running the tests

```bash
pytest -q
```

The suite (16 tests) covers form provisioning, validation pass/fail branches,
field-rule validation, PMO approve/reject routing, BGV completion,
intent detection, the knowledge base, and agent integration. It runs against
an in-memory database and needs no external services.

---

## Notes on customisation

- **Form fields** — edit `app/services/form_template.py` to change the BGV
  form's fields, sections, mandatory flags and validation rules.
- **FAQ content** — edit `data/knowledge_base/faqs.json`; no code change needed.
- **Database** — change `DATABASE_URL` to point at Postgres/MySQL; the schema
  is created automatically on startup.
- **Email delivery** — set `SMTP_ENABLED=true` and fill in `SMTP_*` to send
  real emails instead of logging them.
