"""FastAPI application entry point for the Employee Onboarding AI Agent.

Wires together the API routers, initialises the database, serves the demo
frontend, and starts the background SLA escalation scheduler on startup.
"""
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from app.api import admin_routes, chat_routes, onboarding_routes, pmo_email_routes
from app.core.config import get_settings
from app.core.database import init_db
from app.core.logging_config import get_logger
from app.services.scheduler import shutdown_scheduler, start_scheduler

logger = get_logger(__name__)
settings = get_settings()

_FRONTEND_DIR = Path(__file__).resolve().parents[1] / "frontend"


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application startup/shutdown lifecycle."""
    logger.info("Starting %s ...", settings.app_name)
    init_db()
    start_scheduler()
    yield
    shutdown_scheduler()
    logger.info("%s stopped.", settings.app_name)


app = FastAPI(
    title=settings.app_name,
    description=(
        "Conversational AI agent that automates employee onboarding with "
        "background verification (BGV), PMO approval, real-time notifications, "
        "an FAQ knowledge base and SLA-driven escalation."
    ),
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# API routers
app.include_router(chat_routes.router)
app.include_router(onboarding_routes.router)
app.include_router(admin_routes.router)
app.include_router(pmo_email_routes.router)


@app.get("/health", tags=["meta"])
def health() -> dict:
    """Liveness probe."""
    return {"status": "ok", "app": settings.app_name}


# Demo frontend (served at /)
if _FRONTEND_DIR.exists():
    app.mount(
        "/static", StaticFiles(directory=str(_FRONTEND_DIR)), name="static"
    )

    @app.get("/", include_in_schema=False)
    def index() -> FileResponse:
        return FileResponse(str(_FRONTEND_DIR / "index.html"))


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "app.main:app",
        host=settings.app_host,
        port=settings.app_port,
        reload=settings.app_env == "development",
    )
