"""Intent detection for the conversational onboarding agent.

A deterministic, rule-based NLU classifies each employee message into one of
the onboarding intents. This keeps the agent fully functional with zero
external dependencies. If ``LLM_ENABLED`` is set, ``detect_intent`` can be
extended to delegate to an LLM — the rule-based path remains the default and
the safe fallback.
"""
from __future__ import annotations

import re
from enum import Enum

from app.core.config import get_settings


class Intent(str, Enum):
    """Recognised employee intents."""
    REQUEST_FORM = "REQUEST_FORM"          # steps 1-2
    SUBMIT_FORM = "SUBMIT_FORM"            # step 3
    CHECK_STATUS = "CHECK_STATUS"          # step 8 (employee-initiated)
    FAQ_QUERY = "FAQ_QUERY"                # step 9
    GREETING = "GREETING"
    HELP = "HELP"
    UNKNOWN = "UNKNOWN"


# Ordered keyword rules — first matching intent wins.
_RULES: list[tuple[Intent, list[str]]] = [
    (
        Intent.REQUEST_FORM,
        [
            "request form", "bgv form", "verification form", "get form",
            "start onboarding", "begin onboarding", "need the form",
            "share the form", "send me the form", "onboarding form",
        ],
    ),
    (
        Intent.SUBMIT_FORM,
        [
            "submit form", "submitting", "completed the form", "filled the form",
            "here are my details", "done with the form", "submit my",
        ],
    ),
    (
        Intent.CHECK_STATUS,
        [
            "status", "where is my", "how far", "progress", "update on",
            "any update", "verification done", "is it approved", "check my",
        ],
    ),
    (
        Intent.HELP,
        ["help", "what can you do", "options", "commands", "menu"],
    ),
    (
        Intent.GREETING,
        ["hello", "hi ", "hey", "good morning", "good afternoon", "greetings"],
    ),
]

_GREETING_EXACT = {"hi", "hello", "hey", "yo", "hii"}


def detect_intent(message: str) -> Intent:
    """Classify a free-text employee message into an Intent."""
    text = f" {message.lower().strip()} "
    stripped = message.lower().strip()

    if stripped in _GREETING_EXACT:
        return Intent.GREETING

    for intent, keywords in _RULES:
        for kw in keywords:
            if kw in text:
                return intent

    # Question-shaped messages with no rule hit are treated as FAQ queries
    # so the knowledge base gets a chance to answer (PPT step 9).
    if "?" in message or re.match(r"^(what|how|who|when|where|why|can|do)\b", stripped):
        return Intent.FAQ_QUERY

    return Intent.UNKNOWN


def llm_enabled() -> bool:
    """Whether LLM-backed intent detection is configured."""
    settings = get_settings()
    return settings.llm_enabled and bool(settings.anthropic_api_key)
