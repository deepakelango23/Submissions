"""Conversational onboarding agent.

Turns a free-text employee message into an action by:
  1. detecting the intent (see intents.py),
  2. invoking the WorkflowOrchestrator for workflow intents, or the
     KnowledgeBaseService for FAQ intents,
  3. returning a natural-language reply plus structured ``data``.

This is the "ICA Agent" box in the architecture diagram — the bridge between
the chat surface and the workflow / validation engine.
"""
from __future__ import annotations

import uuid

from sqlalchemy.orm import Session

from app.core.logging_config import get_logger
from app.agent.intents import Intent, detect_intent
from app.models.entities import ChatMessage, Employee
from app.models.enums import FormStatus
from app.models.schemas import ChatResponse
from app.services.knowledge_base import knowledge_base
from app.services.workflow import WorkflowOrchestrator

logger = get_logger(__name__)


class OnboardingAgent:
    """Conversational front door to the onboarding workflow."""

    def __init__(self, db: Session) -> None:
        self.db = db
        self.workflow = WorkflowOrchestrator(db)

    # ── public entry point ───────────────────────────────────

    def handle_message(
        self,
        message: str,
        session_id: str | None = None,
        employee_id: str | None = None,
    ) -> ChatResponse:
        """Process one employee message and return the agent's response."""
        session_id = session_id or str(uuid.uuid4())
        intent = detect_intent(message)
        logger.info("Chat [%s] intent=%s", session_id[:8], intent.value)

        self._log_turn(session_id, employee_id, "user", message, intent.value)

        employee = self.db.get(Employee, employee_id) if employee_id else None

        handler = {
            Intent.GREETING: self._handle_greeting,
            Intent.HELP: self._handle_help,
            Intent.REQUEST_FORM: self._handle_request_form,
            Intent.SUBMIT_FORM: self._handle_submit_hint,
            Intent.CHECK_STATUS: self._handle_check_status,
            Intent.FAQ_QUERY: self._handle_faq,
            Intent.UNKNOWN: self._handle_unknown,
        }[intent]

        reply, data = handler(message, employee)

        self._log_turn(session_id, employee_id, "agent", reply, intent.value)

        return ChatResponse(
            session_id=session_id, intent=intent.value, reply=reply, data=data
        )

    # ── intent handlers ──────────────────────────────────────

    def _handle_greeting(self, message: str, employee: Employee | None):
        name = employee.employee_name.split()[0] if employee else "there"
        reply = (
            f"Hello {name}! I'm the Employee Onboarding Assistant. "
            "I can share your background verification (BGV) form, check your "
            "onboarding status, or answer general onboarding questions. "
            "How can I help?"
        )
        return reply, None

    def _handle_help(self, message: str, employee: Employee | None):
        reply = (
            "Here's what I can do:\n"
            "  • Request your BGV form — say \"I need the verification form\"\n"
            "  • Submit your form — fill the shared form and submit it\n"
            "  • Check status — ask \"what's the status of my onboarding?\"\n"
            "  • Answer questions — e.g. system access, contacts, timelines\n\n"
            "You can also ask things like: "
            + "; ".join(f'"{q}"' for q in knowledge_base.all_questions()[:3])
        )
        return reply, None

    def _handle_request_form(self, message: str, employee: Employee | None):
        if employee is None:
            return (
                "I'd be happy to share the BGV form. First I need to identify "
                "you — please register or provide your employee record so I "
                "can attach the form to your profile.",
                {"requires": "employee_registration"},
            )
        form = self.workflow.request_form(employee)
        field_summary = [
            {
                "field_id": f.field_id,
                "label": f.field_label,
                "type": f.field_type.value,
                "mandatory": f.is_mandatory,
                "section": f.section.value,
            }
            for f in sorted(form.fields, key=lambda x: x.field_order)
        ]
        sections = sorted({f["section"].lower() for f in field_summary})
        sections_phrase = ", ".join(sections) if sections else "the relevant"
        reply = (
            f"Here is your background verification form "
            f"({form.form_reference}). It has {len(field_summary)} fields "
            f"across the {sections_phrase} section(s). Please complete all "
            f"mandatory fields and submit — I'll validate it instantly and "
            f"route it to the PMO team."
        )
        return reply, {"form_id": form.form_id, "fields": field_summary}

    def _handle_submit_hint(self, message: str, employee: Employee | None):
        # Actual submission carries structured field values, so it goes
        # through the dedicated /forms/{id}/submit endpoint. In chat we guide
        # the employee there.
        reply = (
            "To submit your form, please fill in the field values and send "
            "them through the form submission endpoint (the portal does this "
            "for you). Once submitted I'll validate every mandatory field and "
            "let you know immediately if anything needs correction."
        )
        return reply, {"hint": "use POST /api/forms/{form_id}/submit"}

    def _handle_check_status(self, message: str, employee: Employee | None):
        if employee is None:
            return (
                "I can check that once I know who you are — please provide "
                "your employee record first.",
                {"requires": "employee_registration"},
            )
        form = self.workflow.forms.get_active_form_for_employee(
            employee.employee_id
        )
        if form is None:
            return (
                "I don't see a background verification form for you yet. "
                "Say \"I need the verification form\" and I'll create one.",
                {"onboarding_status": employee.onboarding_status.value},
            )

        stage = self._describe_stage(form.form_status)
        reply = (
            f"Here's where things stand:\n"
            f"  Form reference : {form.form_reference}\n"
            f"  Onboarding     : {employee.onboarding_status.value}\n"
            f"  Form status    : {form.form_status.value}\n"
            f"  PMO approval   : {form.pmo_approval_status.value}\n\n"
            f"{stage}"
        )
        data = {
            "form_id": form.form_id,
            "form_status": form.form_status.value,
            "validation_status": form.validation_status.value,
            "pmo_approval_status": form.pmo_approval_status.value,
            "onboarding_status": employee.onboarding_status.value,
            "missing_fields": form.missing_field_list,
        }
        return reply, data

    def _handle_faq(self, message: str, employee: Employee | None):
        answer = knowledge_base.answer(message)
        if answer:
            return answer, {"source": "knowledge_base"}
        suggestions = "; ".join(
            f'"{q}"' for q in knowledge_base.all_questions()[:4]
        )
        return (
            "I don't have a specific answer for that. You can ask me about "
            f"things like: {suggestions}. For anything else, the PMO team can "
            "help directly.",
            {"source": "knowledge_base", "matched": False},
        )

    def _handle_unknown(self, message: str, employee: Employee | None):
        # Give the knowledge base one more chance before giving up.
        answer = knowledge_base.answer(message)
        if answer:
            return answer, {"source": "knowledge_base"}
        return (
            "I'm not sure I followed that. I can share your BGV form, check "
            "your onboarding status, or answer onboarding questions. Try "
            "\"help\" to see everything I can do.",
            None,
        )

    # ── helpers ──────────────────────────────────────────────

    @staticmethod
    def _describe_stage(status: FormStatus) -> str:
        return {
            FormStatus.DRAFT: "Your form is ready to be filled in and submitted.",
            FormStatus.SUBMITTED: "Your form has been submitted and is being validated.",
            FormStatus.INCOMPLETE: (
                "Your form was returned because some mandatory fields need "
                "attention. Please correct them and resubmit."
            ),
            FormStatus.UNDER_REVIEW: "Your form is with the PMO team for review.",
            FormStatus.APPROVED: (
                "Your form is approved — background verification is in "
                "progress. You'll get updates as it proceeds."
            ),
            FormStatus.REJECTED: (
                "Your form was rejected by the PMO team. Please check the "
                "reviewer comments in the rejection email."
            ),
        }.get(status, "")

    def _log_turn(
        self,
        session_id: str,
        employee_id: str | None,
        role: str,
        content: str,
        intent: str,
    ) -> None:
        self.db.add(
            ChatMessage(
                session_id=session_id,
                employee_id=employee_id,
                role=role,
                content=content,
                intent=intent,
            )
        )
        self.db.commit()
