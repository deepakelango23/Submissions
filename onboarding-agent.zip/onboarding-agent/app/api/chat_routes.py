"""Chat API — conversational entry point to the onboarding agent."""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.agent.onboarding_agent import OnboardingAgent
from app.core.database import get_db
from app.models.schemas import ChatRequest, ChatResponse

router = APIRouter(prefix="/api/chat", tags=["chat"])


@router.post("", response_model=ChatResponse)
def chat(payload: ChatRequest, db: Session = Depends(get_db)) -> ChatResponse:
    """Send a message to the onboarding agent and get a reply.

    This is workflow step 1's entry point — the employee initiates a chat to
    request the BGV form — and also serves status checks (step 8) and FAQ
    queries (step 9).
    """
    agent = OnboardingAgent(db)
    return agent.handle_message(
        message=payload.message,
        session_id=payload.session_id,
        employee_id=payload.employee_id,
    )
