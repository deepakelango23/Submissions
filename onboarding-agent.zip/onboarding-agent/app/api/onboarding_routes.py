"""Onboarding API — employees, forms, PMO review and BGV updates.

These endpoints expose the workflow steps that carry structured data:
  * POST /employees                       register an employee
  * POST /employees/upload-excel          bulk upload employees from Excel
  * POST /employees/{id}/form             request a BGV form        (steps 1-2)
  * POST /forms/{id}/submit               submit & validate a form  (steps 3-5)
  * POST /forms/{id}/pmo-review           record PMO decision       (step 6)
  * POST /forms/{id}/bgv-update           record a BGV team update  (step 8)
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.database import get_db
from app.models.entities import (
    BackgroundVerificationTeam,
    Employee,
    OnboardingForm,
)
from app.models.enums import PmoApprovalStatus
from app.models.schemas import (
    BgvUpdateRequest,
    EmployeeCreate,
    EmployeeOut,
    FormFieldOut,
    FormOut,
    FormSubmitRequest,
    PmoReviewRequest,
    ValidationResult,
)
from app.services.excel_service import ExcelService, ExcelValidationError
from app.services.form_service import FormService
from app.services.workflow import WorkflowError, WorkflowOrchestrator

router = APIRouter(prefix="/api", tags=["onboarding"])


# ── helpers ──────────────────────────────────────────────────


def _form_to_out(form: OnboardingForm) -> FormOut:
    return FormOut(
        form_id=form.form_id,
        form_reference=form.form_reference,
        employee_id=form.employee_id,
        form_status=form.form_status,
        validation_status=form.validation_status,
        pmo_approval_status=form.pmo_approval_status,
        submitted_date=form.submitted_date,
        pmo_approved_date=form.pmo_approved_date,
        pmo_reviewer_comments=form.pmo_reviewer_comments,
        missing_fields=form.missing_field_list,
        fields=[
            FormFieldOut.model_validate(f)
            for f in sorted(form.fields, key=lambda x: x.field_order)
        ],
    )


def _get_form_or_404(db: Session, form_id: str) -> OnboardingForm:
    form = db.get(OnboardingForm, form_id)
    if form is None:
        raise HTTPException(status_code=404, detail="Form not found")
    return form


# ── employees ────────────────────────────────────────────────


@router.post("/employees", response_model=EmployeeOut, status_code=201)
def create_employee(
    payload: EmployeeCreate, db: Session = Depends(get_db)
) -> EmployeeOut:
    """Register a new employee (precondition for requesting a BGV form)."""
    # Check for duplicate talent_id
    existing = db.query(Employee).filter(Employee.talent_id == payload.talent_id).first()
    if existing:
        raise HTTPException(
            status_code=409, detail=f"An employee with Talent ID '{payload.talent_id}' already exists"
        )
    
    employee = Employee(
        talent_id=payload.talent_id,
        employee_name=payload.employee_name,
        project_id=payload.project_id,
        account_focal_email=payload.account_focal_email,
        emp_type=payload.emp_type,
        account_name=payload.account_name,
        project_name=payload.project_name,
        project_dept_code=payload.project_dept_code,
        account_id=payload.account_id,
        dou_number=payload.dou_number,
        date_requested=payload.date_requested,
        email=payload.email or payload.account_focal_email,
        phone=payload.phone,
        department=payload.department,
        designation=payload.designation,
        joining_date=payload.joining_date,
    )
    db.add(employee)
    db.commit()
    db.refresh(employee)
    return EmployeeOut.model_validate(employee)


@router.post("/employees/upload-excel", status_code=201)
async def upload_employees_excel(
    file: UploadFile = File(..., description="Excel file with employee onboarding data"),
    skip_duplicates: bool = False,
    db: Session = Depends(get_db),
) -> dict:
    """
    Bulk upload employees from an Excel file.

    The Excel file must follow the onboarding_template schema. Any column not
    listed below will cause the upload to be rejected.

    Mandatory columns (must be present AND non-empty in every row):
    - Emp # / Talent ID
    - Emp Name
    - Emp Type
    - Account Name
    - Account Focal email
    - Project ID
    - Project Name

    Optional columns (allowed, but may be blank):
    - Project Dept Code
    - Account ID
    - DOU Number
    - Date Requested

    Args:
        file: Excel file (.xlsx) matching the onboarding_template
        skip_duplicates: If True, skip rows with duplicate Talent IDs instead of failing

    Returns:
        Summary of upload results including created, skipped, and error counts
    """
    # Validate file type
    if not file.filename or not file.filename.endswith(('.xlsx', '.xls')):
        raise HTTPException(
            status_code=400,
            detail="Invalid file type. Please upload an Excel file (.xlsx or .xls)"
        )
    
    try:
        # Read file content
        content = await file.read()
        
        # Process with Excel service
        excel_service = ExcelService(db)
        
        # Validate and parse Excel
        validated_rows = excel_service.validate_and_parse_excel(content, file.filename)
        
        # Create employees
        result = excel_service.create_employees_from_excel(validated_rows, skip_duplicates)
        
        return {
            "message": f"Successfully processed {len(validated_rows)} rows",
            "filename": file.filename,
            "total_rows": len(validated_rows),
            "created": result["created"],
            "skipped": result["skipped"],
            "errors": result["errors"],
            "duplicates": result["duplicates"],
            "created_employees": result.get("created_employees", []),
        }
        
    except ExcelValidationError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to process Excel file: {str(e)}"
        )


@router.get("/employees/{employee_id}", response_model=EmployeeOut)
def get_employee(employee_id: str, db: Session = Depends(get_db)) -> EmployeeOut:
    employee = db.get(Employee, employee_id)
    if employee is None:
        raise HTTPException(status_code=404, detail="Employee not found")
    return EmployeeOut.model_validate(employee)


@router.get("/employees/by-talent-id/{talent_id}", response_model=EmployeeOut)
def get_employee_by_talent_id(
    talent_id: str,
    db: Session = Depends(get_db)
) -> EmployeeOut:
    """Get an employee by their talent_id."""
    employee = db.query(Employee).filter(Employee.talent_id == talent_id).first()
    if employee is None:
        raise HTTPException(status_code=404, detail=f"Employee with talent_id '{talent_id}' not found")
    return EmployeeOut.model_validate(employee)


# ── forms ────────────────────────────────────────────────────


@router.post("/employees/{employee_id}/form", response_model=FormOut, status_code=201)
def request_form(employee_id: str, db: Session = Depends(get_db)) -> FormOut:
    """Steps 1-2 — provision and share a BGV form for an employee."""
    employee = db.get(Employee, employee_id)
    if employee is None:
        raise HTTPException(status_code=404, detail="Employee not found")
    orchestrator = WorkflowOrchestrator(db)
    form = orchestrator.request_form(employee)
    return _form_to_out(form)


@router.get("/forms/{form_id}", response_model=FormOut)
def get_form(form_id: str, db: Session = Depends(get_db)) -> FormOut:
    return _form_to_out(_get_form_or_404(db, form_id))


@router.post("/forms/{form_id}/submit", response_model=ValidationResult)
def submit_form(
    form_id: str, payload: FormSubmitRequest, db: Session = Depends(get_db)
) -> ValidationResult:
    """Steps 3-5 — submit form values; validate and route to PMO."""
    form = _get_form_or_404(db, form_id)
    orchestrator = WorkflowOrchestrator(db)
    try:
        return orchestrator.submit_form(form, payload.values)
    except WorkflowError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@router.post("/forms/{form_id}/pmo-review", response_model=FormOut)
def pmo_review(
    form_id: str, payload: PmoReviewRequest, db: Session = Depends(get_db)
) -> FormOut:
    """Step 6 — record the PMO team's approve/reject decision."""
    if payload.decision not in (
        PmoApprovalStatus.APPROVED,
        PmoApprovalStatus.REJECTED,
    ):
        raise HTTPException(
            status_code=400, detail="decision must be APPROVED or REJECTED"
        )
    form = _get_form_or_404(db, form_id)
    orchestrator = WorkflowOrchestrator(db)
    try:
        updated = orchestrator.pmo_review(
            form, payload.decision, payload.reviewer_name, payload.comments
        )
    except WorkflowError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    return _form_to_out(updated)


@router.post("/forms/{form_id}/bgv-update", response_model=FormOut)
def bgv_update(
    form_id: str, payload: BgvUpdateRequest, db: Session = Depends(get_db)
) -> FormOut:
    """Step 8 — record a BGV team response and broadcast status updates."""
    form = _get_form_or_404(db, form_id)
    settings = get_settings()

    # Resolve (or lazily create) the BGV team record for this run.
    bgv = db.query(BackgroundVerificationTeam).first()
    if bgv is None:
        bgv = BackgroundVerificationTeam(
            bv_team_name="Background Verification Team",
            bv_email_id=settings.bgv_team_email,
        )
        db.add(bgv)
        db.commit()
        db.refresh(bgv)

    orchestrator = WorkflowOrchestrator(db)
    try:
        updated = orchestrator.record_bgv_update(
            form, bgv, payload.response_status, payload.verification_result
        )
    except WorkflowError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    return _form_to_out(updated)
