"""Admin / observability API.

Exposes notification history, escalation records and a manual trigger for the
SLA escalation sweep — useful for demos and for verifying step 10 behaviour
without waiting for the scheduler interval.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models.entities import EscalationEvent, NotificationEvent
from app.models.schemas import NotificationOut
from app.services.workflow import WorkflowOrchestrator

router = APIRouter(prefix="/api/admin", tags=["admin"])


@router.get("/notifications", response_model=list[NotificationOut])
def list_notifications(
    limit: int = 50, db: Session = Depends(get_db)
) -> list[NotificationOut]:
    """Return the most recent notification events (newest first)."""
    rows = (
        db.query(NotificationEvent)
        .order_by(NotificationEvent.created_at.desc())
        .limit(limit)
        .all()
    )
    return [NotificationOut.model_validate(r) for r in rows]


@router.get("/escalations")
def list_escalations(limit: int = 50, db: Session = Depends(get_db)) -> list[dict]:
    """Return recorded escalation events (newest first)."""
    rows = (
        db.query(EscalationEvent)
        .order_by(EscalationEvent.created_at.desc())
        .limit(limit)
        .all()
    )
    return [
        {
            "escalation_id": r.escalation_id,
            "form_id": r.form_id,
            "stage": r.stage.value if hasattr(r.stage, "value") else r.stage,
            "reason": r.reason,
            "minutes_overdue": r.minutes_overdue,
            "created_at": r.created_at,
        }
        for r in rows
    ]


@router.post("/run-escalation-sweep")
def run_escalation_sweep(db: Session = Depends(get_db)) -> dict:
    """Manually run the SLA escalation sweep (PPT workflow step 10)."""
    orchestrator = WorkflowOrchestrator(db)
    count = orchestrator.run_escalation_sweep()
    return {"breaches_detected": count}
