"""Public PMO action endpoints — invoked from the buttons in the PMO email.

Three routes:
  GET  /pmo/forms/{form_id}/approve  → one-click approval, returns confirmation HTML
  GET  /pmo/forms/{form_id}/reject   → reject reason form
  POST /pmo/forms/{form_id}/reject   → finalises rejection with the provided reason
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, Form, HTTPException
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models.entities import OnboardingForm
from app.models.enums import PmoApprovalStatus
from app.services.workflow import WorkflowError, WorkflowOrchestrator

router = APIRouter(prefix="/pmo", tags=["pmo-email"])


# ── helpers ────────────────────────────────────────────────────


def _get_form(db: Session, form_id: str) -> OnboardingForm:
    form = db.get(OnboardingForm, form_id)
    if form is None:
        raise HTTPException(status_code=404, detail="Form not found")
    return form


def _page(title: str, message_html: str, *, ok: bool = True) -> str:
    color = "#2ea043" if ok else "#d9544f"
    return f"""\
<!DOCTYPE html>
<html><head><title>{title}</title></head>
<body style="font-family:Arial,sans-serif;max-width:560px;margin:48px auto;color:#222;">
  <h2 style="color:{color};margin-bottom:8px;">{title}</h2>
  <div style="font-size:14px;line-height:1.6;">{message_html}</div>
  <p style="font-size:11px;color:#999;margin-top:32px;">
    You can close this tab. Refresh the onboarding app to see the updated status.
  </p>
</body></html>"""


def _summary_rows(form: OnboardingForm) -> str:
    fields = sorted(form.fields, key=lambda f: f.field_order)
    return "".join(
        f"<tr><td style='padding:4px 10px;border:1px solid #ddd;background:#f7f9fc;"
        f"font-weight:600;'>{f.field_label}</td>"
        f"<td style='padding:4px 10px;border:1px solid #ddd;'>"
        f"{(f.field_value or '(blank)')}</td></tr>"
        for f in fields
    )


# ── approve ───────────────────────────────────────────────────


@router.get("/forms/{form_id}/approve", response_class=HTMLResponse)
def approve(form_id: str, db: Session = Depends(get_db)) -> HTMLResponse:
    form = _get_form(db, form_id)
    if form.pmo_approval_status == PmoApprovalStatus.APPROVED:
        return HTMLResponse(_page(
            "Already approved",
            f"Form <b>{form.form_reference}</b> was already approved.",
        ))
    if form.pmo_approval_status == PmoApprovalStatus.REJECTED:
        return HTMLResponse(_page(
            "Already rejected",
            f"Form <b>{form.form_reference}</b> was already rejected and cannot be approved.",
            ok=False,
        ), status_code=409)

    orchestrator = WorkflowOrchestrator(db)
    try:
        orchestrator.pmo_review(
            form, PmoApprovalStatus.APPROVED, reviewer_name="PMO via email"
        )
    except WorkflowError as exc:
        return HTMLResponse(_page("Cannot approve", str(exc), ok=False), status_code=409)

    return HTMLResponse(_page(
        "✓ Form Approved",
        f"Form <b>{form.form_reference}</b> has been approved. "
        "The employee and BGV team have been notified.",
    ))


# ── reject (reason form, then submit) ─────────────────────────


@router.get("/forms/{form_id}/reject", response_class=HTMLResponse)
def reject_form_page(form_id: str, db: Session = Depends(get_db)) -> HTMLResponse:
    form = _get_form(db, form_id)
    if form.pmo_approval_status == PmoApprovalStatus.REJECTED:
        return HTMLResponse(_page(
            "Already rejected",
            f"Form <b>{form.form_reference}</b> was already rejected.",
        ))
    if form.pmo_approval_status == PmoApprovalStatus.APPROVED:
        return HTMLResponse(_page(
            "Already approved",
            f"Form <b>{form.form_reference}</b> was already approved and cannot be rejected.",
            ok=False,
        ), status_code=409)

    rows = _summary_rows(form)
    html = f"""\
<!DOCTYPE html>
<html><head><title>Reject form {form.form_reference}</title></head>
<body style="font-family:Arial,sans-serif;max-width:640px;margin:40px auto;color:#222;">
  <h2 style="color:#d9544f;margin-bottom:4px;">Reject form {form.form_reference}</h2>
  <p style="color:#666;margin-top:0;">Provide a resubmission reason for the employee.</p>

  <table style="border-collapse:collapse;font-size:13px;margin:16px 0;">{rows}</table>

  <form method="post" action="/pmo/forms/{form_id}/reject">
    <label style="display:block;font-weight:600;margin-bottom:6px;">Reason for rejection</label>
    <textarea name="reason" rows="4" required
      style="width:100%;padding:8px;border:1px solid #ccc;border-radius:6px;font-family:inherit;font-size:14px;"
      placeholder="e.g. Account Name does not match the employee record. Please correct and resubmit."></textarea>
    <p style="margin-top:14px;">
      <button type="submit"
        style="background:#d9544f;color:#fff;padding:10px 20px;border:0;border-radius:6px;
               font-weight:600;cursor:pointer;font-size:14px;">
        Send rejection
      </button>
    </p>
  </form>
</body></html>"""
    return HTMLResponse(html)


@router.post("/forms/{form_id}/reject", response_class=HTMLResponse)
def reject_submit(
    form_id: str,
    reason: str = Form(...),
    db: Session = Depends(get_db),
) -> HTMLResponse:
    form = _get_form(db, form_id)
    reason = reason.strip()
    if not reason:
        return HTMLResponse(
            _page("Reason required", "A rejection reason is required.", ok=False),
            status_code=400,
        )

    orchestrator = WorkflowOrchestrator(db)
    try:
        orchestrator.pmo_review(
            form,
            PmoApprovalStatus.REJECTED,
            reviewer_name="PMO via email",
            comments=reason,
        )
    except WorkflowError as exc:
        return HTMLResponse(_page("Cannot reject", str(exc), ok=False), status_code=409)

    return HTMLResponse(_page(
        "✗ Form Rejected",
        f"Form <b>{form.form_reference}</b> has been rejected. The employee has been "
        f"notified with the reason:<br><br><i>{reason}</i>",
        ok=False,
    ))
