"""Pydantic schemas used for API request validation and responses."""
from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, EmailStr, Field

from app.models.enums import (
    BgvResponseStatus,
    FieldSection,
    FieldType,
    FormStatus,
    NotificationType,
    OnboardingStatus,
    PmoApprovalStatus,
    ValidationStatus,
    VerificationResult,
)

# ── Employee ─────────────────────────────────────────────────


class EmployeeCreate(BaseModel):
    """Schema for creating an employee - supports both legacy and Excel-based creation."""
    # Mandatory fields from Excel
    talent_id: str = Field(..., min_length=1, max_length=50, description="Emp # / Talent ID")
    employee_name: str = Field(..., min_length=1, max_length=200, description="Emp Name")
    project_id: str = Field(..., min_length=1, max_length=100, description="Project ID")
    account_focal_email: EmailStr = Field(..., description="Account Focal email")
    
    # Additional Excel fields
    emp_type: str | None = Field(None, max_length=50, description="Emp Type")
    account_name: str | None = Field(None, max_length=200, description="Account Name")
    project_name: str | None = Field(None, max_length=200, description="Project Name")
    project_dept_code: str | None = Field(None, max_length=50, description="Project Dept Code")
    account_id: str | None = Field(None, max_length=100, description="Account ID")
    dou_number: str | None = Field(None, max_length=100, description="DOU Number")
    date_requested: datetime | None = Field(None, description="Date Requested")
    
    # Legacy fields (optional for backward compatibility)
    email: EmailStr | None = None
    phone: str | None = None
    department: str | None = None
    designation: str | None = None
    joining_date: datetime | None = None


class EmployeeOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    employee_id: str
    talent_id: str
    employee_name: str
    project_id: str
    account_focal_email: str
    emp_type: str | None
    account_name: str | None
    project_name: str | None
    project_dept_code: str | None
    account_id: str | None
    dou_number: str | None
    date_requested: datetime | None
    email: str | None
    phone: str | None
    department: str | None
    designation: str | None
    joining_date: datetime | None
    onboarding_status: OnboardingStatus


class ExcelEmployeeRow(BaseModel):
    """Schema for a single row from the Excel file.

    Required fields (the seven mandatory attributes) are enforced here. Extra
    columns outside the onboarding template are rejected by ``extra="forbid"``.
    """
    talent_id: str = Field(..., alias="Emp # / Talent ID")
    employee_name: str = Field(..., alias="Emp Name")
    emp_type: str = Field(..., alias="Emp Type")
    account_name: str = Field(..., alias="Account Name")
    account_focal_email: str = Field(..., alias="Account Focal\nemail")
    project_id: str = Field(..., alias="Project ID")
    project_name: str = Field(..., alias="Project Name")
    project_dept_code: str | None = Field(None, alias="Project Dept Code")
    account_id: str | None = Field(None, alias="Account ID")
    dou_number: str | None = Field(None, alias="DOU Number")
    date_requested: datetime | None = Field(None, alias="Date\nRequested")

    model_config = ConfigDict(populate_by_name=True, extra="forbid")


# ── Form fields ──────────────────────────────────────────────


class FormFieldOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    field_id: str
    field_label: str
    field_type: FieldType
    is_mandatory: bool
    field_value: str | None
    is_filled: bool
    validation_rule: str | None
    section: FieldSection
    field_order: int


class FieldValueIn(BaseModel):
    """A single field value supplied by the employee on submission."""
    field_id: str
    value: str


class FormSubmitRequest(BaseModel):
    values: list[FieldValueIn]


# ── Forms ────────────────────────────────────────────────────


class FormOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    form_id: str
    form_reference: str
    employee_id: str
    form_status: FormStatus
    validation_status: ValidationStatus
    pmo_approval_status: PmoApprovalStatus
    submitted_date: datetime | None
    pmo_approved_date: datetime | None
    pmo_reviewer_comments: str | None
    missing_fields: list[str] = []
    fields: list[FormFieldOut] = []


class ValidationResult(BaseModel):
    """Outcome of a form validation pass (PPT workflow step 4)."""
    is_valid: bool
    validation_status: ValidationStatus
    missing_fields: list[str] = []
    invalid_fields: list[str] = []
    message: str


# ── PMO review ───────────────────────────────────────────────


class PmoReviewRequest(BaseModel):
    decision: PmoApprovalStatus  # APPROVED or REJECTED
    reviewer_name: str | None = None
    comments: str | None = None


# ── BGV updates ──────────────────────────────────────────────


class BgvUpdateRequest(BaseModel):
    response_status: BgvResponseStatus
    verification_result: VerificationResult = VerificationResult.PENDING
    notes: str | None = None


# ── Chat ─────────────────────────────────────────────────────


class ChatRequest(BaseModel):
    session_id: str | None = None
    employee_id: str | None = None
    message: str = Field(..., min_length=1)


class ChatResponse(BaseModel):
    session_id: str
    intent: str
    reply: str
    data: dict | None = None


# ── Notifications ────────────────────────────────────────────


class NotificationOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    event_id: str
    notification_type: NotificationType
    recipients: str
    cc_recipients: str
    subject: str
    body: str
    is_sent: bool
    created_at: datetime
