"""ORM entity models.

Each model maps directly to an Entity defined in the supplied JSON schema
(`onboard:Employee`, `onboard:PMOTeam`, `onboard:OnboardingForm`, etc.).
Invariants from the schema are enforced at the service layer; column-level
constraints below cover the structural ones (uniqueness, non-null).
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import (
    Boolean,
    DateTime,
    ForeignKey,
    Integer,
    String,
    Text,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base
from app.core.types import EnumType
from app.models.enums import (
    BgvResponseStatus,
    FieldSection,
    FieldType,
    FormStatus,
    NotificationChannel,
    NotificationType,
    OnboardingStatus,
    PmoApprovalStatus,
    SlaStage,
    ValidationStatus,
    VerificationResult,
)


def _uuid() -> str:
    return str(uuid.uuid4())


def _now() -> datetime:
    return datetime.now(timezone.utc)


class Employee(Base):
    """onboard:Employee — new employee being onboarded."""

    __tablename__ = "employees"

    employee_id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    # Mandatory fields from Excel
    talent_id: Mapped[str] = mapped_column(String(50), nullable=False, unique=True)  # Emp # / Talent ID
    employee_name: Mapped[str] = mapped_column(String(200), nullable=False)  # Emp Name
    project_id: Mapped[str] = mapped_column(String(100), nullable=False)  # Project ID
    account_focal_email: Mapped[str] = mapped_column(String(255), nullable=False)  # Account Focal email
    
    # Additional Excel fields
    emp_type: Mapped[str | None] = mapped_column(String(50))  # Emp Type
    account_name: Mapped[str | None] = mapped_column(String(200))  # Account Name
    project_name: Mapped[str | None] = mapped_column(String(200))  # Project Name
    project_dept_code: Mapped[str | None] = mapped_column(String(50))  # Project Dept Code
    account_id: Mapped[str | None] = mapped_column(String(100))  # Account ID
    dou_number: Mapped[str | None] = mapped_column(String(100))  # DOU Number
    date_requested: Mapped[datetime | None] = mapped_column(DateTime)  # Date Requested
    
    # Legacy fields (kept for backward compatibility)
    email: Mapped[str | None] = mapped_column(String(255))
    phone: Mapped[str | None] = mapped_column(String(30))
    department: Mapped[str | None] = mapped_column(String(120))
    designation: Mapped[str | None] = mapped_column(String(120))
    joining_date: Mapped[datetime | None] = mapped_column(DateTime)
    
    onboarding_status: Mapped[OnboardingStatus] = mapped_column(
        EnumType(OnboardingStatus, 20), default=OnboardingStatus.INITIATED
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)

    forms: Mapped[list["OnboardingForm"]] = relationship(
        back_populates="employee", cascade="all, delete-orphan"
    )


class PMOTeam(Base):
    """onboard:PMOTeam — validates and approves BGV forms."""

    __tablename__ = "pmo_teams"

    pmo_team_id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    pmo_team_name: Mapped[str] = mapped_column(String(200), nullable=False)
    pmo_email_id: Mapped[str] = mapped_column(String(255), nullable=False)
    assigned_reviewer_id: Mapped[str | None] = mapped_column(String(36))
    reviewer_name: Mapped[str | None] = mapped_column(String(200))


class BackgroundVerificationTeam(Base):
    """onboard:BackgroundVerificationTeam — executes BGV checks."""

    __tablename__ = "bgv_teams"

    bv_team_id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    bv_team_name: Mapped[str] = mapped_column(String(200), nullable=False)
    bv_email_id: Mapped[str] = mapped_column(String(255), nullable=False)
    response_status: Mapped[BgvResponseStatus] = mapped_column(
        EnumType(BgvResponseStatus, 20), default=BgvResponseStatus.PENDING
    )
    last_response_date: Mapped[datetime | None] = mapped_column(DateTime)
    verification_result: Mapped[VerificationResult] = mapped_column(
        EnumType(VerificationResult, 20), default=VerificationResult.PENDING
    )


class OnboardingForm(Base):
    """onboard:OnboardingForm — the BGV form filled by the employee."""

    __tablename__ = "onboarding_forms"

    form_id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    form_reference: Mapped[str] = mapped_column(String(40), nullable=False, unique=True)
    employee_id: Mapped[str] = mapped_column(
        ForeignKey("employees.employee_id"), nullable=False
    )
    form_status: Mapped[FormStatus] = mapped_column(
        EnumType(FormStatus, 20), default=FormStatus.DRAFT
    )
    submitted_date: Mapped[datetime | None] = mapped_column(DateTime)
    last_updated_date: Mapped[datetime] = mapped_column(DateTime, default=_now)
    validation_status: Mapped[ValidationStatus] = mapped_column(
        EnumType(ValidationStatus, 20), default=ValidationStatus.PENDING
    )
    # missingFields (schema: array) — stored as comma-separated field ids.
    missing_fields: Mapped[str] = mapped_column(Text, default="")
    pmo_approval_status: Mapped[PmoApprovalStatus] = mapped_column(
        EnumType(PmoApprovalStatus, 20), default=PmoApprovalStatus.PENDING
    )
    pmo_approved_date: Mapped[datetime | None] = mapped_column(DateTime)
    pmo_reviewer_comments: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)

    employee: Mapped["Employee"] = relationship(back_populates="forms")
    fields: Mapped[list["FormField"]] = relationship(
        back_populates="form", cascade="all, delete-orphan"
    )

    @property
    def missing_field_list(self) -> list[str]:
        return [f for f in self.missing_fields.split(",") if f]

    @missing_field_list.setter
    def missing_field_list(self, value: list[str]) -> None:
        self.missing_fields = ",".join(value)


class FormField(Base):
    """onboard:FormField — an individual field within a BGV form."""

    __tablename__ = "form_fields"

    field_id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    form_id: Mapped[str] = mapped_column(
        ForeignKey("onboarding_forms.form_id"), nullable=False
    )
    field_label: Mapped[str] = mapped_column(String(200), nullable=False)
    field_type: Mapped[FieldType] = mapped_column(EnumType(FieldType, 20), default=FieldType.TEXT)
    is_mandatory: Mapped[bool] = mapped_column(Boolean, default=False)
    field_value: Mapped[str | None] = mapped_column(Text)
    is_filled: Mapped[bool] = mapped_column(Boolean, default=False)
    validation_rule: Mapped[str | None] = mapped_column(String(255))
    section: Mapped[FieldSection] = mapped_column(
        EnumType(FieldSection, 20), default=FieldSection.PERSONAL
    )
    field_order: Mapped[int] = mapped_column(Integer, default=0)

    form: Mapped["OnboardingForm"] = relationship(back_populates="fields")


class NotificationEvent(Base):
    """onboard:NotificationEvent — a notification sent to a stakeholder."""

    __tablename__ = "notification_events"

    event_id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    employee_id: Mapped[str | None] = mapped_column(String(36))
    form_id: Mapped[str | None] = mapped_column(String(36))
    notification_type: Mapped[NotificationType] = mapped_column(EnumType(NotificationType, 40))
    channel: Mapped[NotificationChannel] = mapped_column(
        EnumType(NotificationChannel, 20), default=NotificationChannel.EMAIL
    )
    recipients: Mapped[str] = mapped_column(Text)          # comma-separated
    cc_recipients: Mapped[str] = mapped_column(Text, default="")
    subject: Mapped[str] = mapped_column(String(255))
    body: Mapped[str] = mapped_column(Text)
    is_sent: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)


class EscalationEvent(Base):
    """onboard:EscalationEvent — raised when an SLA is breached."""

    __tablename__ = "escalation_events"

    escalation_id: Mapped[str] = mapped_column(
        String(36), primary_key=True, default=_uuid
    )
    form_id: Mapped[str] = mapped_column(String(36), nullable=False)
    stage: Mapped[SlaStage] = mapped_column(EnumType(SlaStage, 30))
    reason: Mapped[str] = mapped_column(Text)
    minutes_overdue: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)


class SlaTimer(Base):
    """Tracks an SLA deadline for a single workflow stage of a form."""

    __tablename__ = "sla_timers"

    timer_id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    form_id: Mapped[str] = mapped_column(String(36), nullable=False)
    stage: Mapped[SlaStage] = mapped_column(EnumType(SlaStage, 30))
    started_at: Mapped[datetime] = mapped_column(DateTime, default=_now)
    due_at: Mapped[datetime] = mapped_column(DateTime)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime)
    is_breached: Mapped[bool] = mapped_column(Boolean, default=False)
    escalated: Mapped[bool] = mapped_column(Boolean, default=False)


class ChatMessage(Base):
    """A single turn in the conversation between an employee and the agent."""

    __tablename__ = "chat_messages"

    message_id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    session_id: Mapped[str] = mapped_column(String(36), nullable=False, index=True)
    employee_id: Mapped[str | None] = mapped_column(String(36))
    role: Mapped[str] = mapped_column(String(20))          # "user" | "agent"
    content: Mapped[str] = mapped_column(Text)
    intent: Mapped[str | None] = mapped_column(String(40))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)
