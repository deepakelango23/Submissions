"""Enumerations mirroring the status fields defined in the JSON schema."""
from enum import Enum


class OnboardingStatus(str, Enum):
    """Employee.onboardingStatus"""
    INITIATED = "INITIATED"
    IN_PROGRESS = "IN_PROGRESS"
    COMPLETED = "COMPLETED"
    ON_HOLD = "ON_HOLD"


class FormStatus(str, Enum):
    """OnboardingForm.formStatus"""
    DRAFT = "DRAFT"
    SUBMITTED = "SUBMITTED"
    INCOMPLETE = "INCOMPLETE"
    UNDER_REVIEW = "UNDER_REVIEW"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"


class ValidationStatus(str, Enum):
    """OnboardingForm.validationStatus"""
    PASS = "PASS"
    FAIL = "FAIL"
    PENDING = "PENDING"


class PmoApprovalStatus(str, Enum):
    """OnboardingForm.pmoApprovalStatus"""
    PENDING = "PENDING"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"


class BgvResponseStatus(str, Enum):
    """BackgroundVerificationTeam.responseStatus"""
    PENDING = "PENDING"
    IN_PROGRESS = "IN_PROGRESS"
    COMPLETED = "COMPLETED"
    DELAYED = "DELAYED"


class VerificationResult(str, Enum):
    """BackgroundVerificationTeam.verificationResult"""
    CLEAR = "CLEAR"
    FLAGGED = "FLAGGED"
    PENDING = "PENDING"


class FieldType(str, Enum):
    """FormField.fieldType"""
    TEXT = "TEXT"
    DATE = "DATE"
    NUMBER = "NUMBER"
    EMAIL = "EMAIL"
    DROPDOWN = "DROPDOWN"
    CHECKBOX = "CHECKBOX"


class FieldSection(str, Enum):
    """FormField.section"""
    PERSONAL = "PERSONAL"
    EDUCATION = "EDUCATION"
    EMPLOYMENT = "EMPLOYMENT"
    IDENTITY = "IDENTITY"
    REFERENCES = "REFERENCES"


class NotificationChannel(str, Enum):
    EMAIL = "EMAIL"
    CHAT = "CHAT"


class NotificationType(str, Enum):
    """High-level reason a notification / event was raised."""
    FORM_SHARED = "FORM_SHARED"
    FORM_RETURNED = "FORM_RETURNED"
    FORM_SUBMITTED = "FORM_SUBMITTED"
    PMO_APPROVED = "PMO_APPROVED"
    PMO_REJECTED = "PMO_REJECTED"
    BGV_TRIGGERED = "BGV_TRIGGERED"
    BGV_STATUS_UPDATE = "BGV_STATUS_UPDATE"
    ESCALATION = "ESCALATION"
    ONBOARDING_COMPLETED = "ONBOARDING_COMPLETED"


class SlaStage(str, Enum):
    """Workflow stage an SLA timer applies to."""
    FORM_VALIDATION = "FORM_VALIDATION"
    PMO_REVIEW = "PMO_REVIEW"
    BGV_COMPLETION = "BGV_COMPLETION"
