"""Workflow orchestrator.

Coordinates the end-to-end employee onboarding process described in the
high-level presentation. Each public method corresponds to one or more
numbered workflow steps and advances the form / employee state machine
while emitting the appropriate notifications and SLA timers.

Workflow steps (from the PPT):
  1-2  Employee requests form  -> agent shares BGV form
  3    Employee submits form
  4    Agent validates form    -> return to employee OR proceed
  5    Submit validated form to PMO team
  6    PMO review              -> reject (notify) OR approve
  7    Approval triggers BGV team email
  8    Monitor BGV responses   -> status updates to Employee + PMO
  10   SLA breach              -> escalation emails
"""
from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.core.logging_config import get_logger
from app.models.entities import (
    BackgroundVerificationTeam,
    Employee,
    OnboardingForm,
)
from app.models.enums import (
    BgvResponseStatus,
    FormStatus,
    OnboardingStatus,
    PmoApprovalStatus,
    SlaStage,
    ValidationStatus,
    VerificationResult,
)
from app.models.schemas import FieldValueIn, ValidationResult
from app.services.form_service import FormService
from app.services.notification_service import NotificationService
from app.services.sla_service import SlaService

logger = get_logger(__name__)


def _now() -> datetime:
    return datetime.now(timezone.utc)


class WorkflowError(Exception):
    """Raised when a workflow transition is attempted out of order."""


class WorkflowOrchestrator:
    """Drives the onboarding state machine across all services."""

    def __init__(self, db: Session) -> None:
        self.db = db
        self.forms = FormService(db)
        self.notifications = NotificationService(db)
        self.sla = SlaService(db)

    # ── Steps 1-2: request & share BGV form ──────────────────

    def request_form(self, employee: Employee) -> OnboardingForm:
        """Employee requests the BGV form; the agent provisions and shares it."""
        existing = self.forms.get_active_form_for_employee(employee.employee_id)
        if existing and existing.form_status in (
            FormStatus.DRAFT,
            FormStatus.INCOMPLETE,
            FormStatus.SUBMITTED,
            FormStatus.UNDER_REVIEW,
        ):
            logger.info(
                "Employee %s already has active form %s — returning it.",
                employee.email,
                existing.form_reference,
            )
            return existing

        form = self.forms.create_form(employee)
        employee.onboarding_status = OnboardingStatus.IN_PROGRESS
        self.db.commit()
        return form

    # ── Steps 3-5: submit, validate, route to PMO ────────────

    def submit_form(
        self, form: OnboardingForm, values: list[FieldValueIn]
    ) -> ValidationResult:
        """Apply employee values, validate, and route the form (PPT steps 3-5).

        Returns the ValidationResult. On success the form is sent to the PMO
        team; on failure it is returned to the employee for completion.
        """
        if form.form_status in (FormStatus.APPROVED, FormStatus.UNDER_REVIEW):
            raise WorkflowError(
                f"Form {form.form_reference} is already {form.form_status.value}."
            )

        # Step 4 SLA: form validation should complete quickly.
        self.sla.start_timer(form.form_id, SlaStage.FORM_VALIDATION)

        self.forms.apply_values(form, values)
        result = self.forms.validate_form(form)

        self.sla.complete_timer(form.form_id, SlaStage.FORM_VALIDATION)

        employee = self.db.get(Employee, form.employee_id)

        if not result.is_valid:
            # Step 4 (fail branch): return form to employee.
            self.notifications.notify_form_returned(
                employee, form, result.missing_fields + result.invalid_fields
            )
            logger.info("Form %s returned to employee.", form.form_reference)
            return result

        # Step 5: validated form submitted to PMO; start PMO review SLA.
        self.notifications.notify_pmo_submission(employee, form)
        self.sla.start_timer(form.form_id, SlaStage.PMO_REVIEW)
        logger.info("Form %s submitted to PMO team.", form.form_reference)
        return result

    # ── Step 6: PMO review ───────────────────────────────────

    def pmo_review(
        self,
        form: OnboardingForm,
        decision: PmoApprovalStatus,
        reviewer_name: str | None = None,
        comments: str | None = None,
    ) -> OnboardingForm:
        """Record the PMO decision and route accordingly (PPT step 6)."""
        if form.validation_status != ValidationStatus.PASS:
            raise WorkflowError(
                f"Form {form.form_reference} has not passed validation."
            )
        if form.pmo_approval_status != PmoApprovalStatus.PENDING:
            raise WorkflowError(
                f"Form {form.form_reference} was already reviewed "
                f"({form.pmo_approval_status.value})."
            )

        form.pmo_approval_status = decision
        form.pmo_approved_date = _now()
        form.pmo_reviewer_comments = comments
        form.last_updated_date = _now()

        self.sla.complete_timer(form.form_id, SlaStage.PMO_REVIEW)
        employee = self.db.get(Employee, form.employee_id)

        if decision == PmoApprovalStatus.REJECTED:
            form.form_status = FormStatus.REJECTED
            employee.onboarding_status = OnboardingStatus.ON_HOLD
            self.db.commit()
            self.notifications.notify_pmo_decision(employee, form, approved=False)
            logger.info("Form %s rejected by PMO.", form.form_reference)
            return form

        # Approved -> proceed to BGV (step 7).
        form.form_status = FormStatus.APPROVED
        self.db.commit()
        self.notifications.notify_pmo_decision(employee, form, approved=True)
        self._trigger_bgv(employee, form)
        return form

    # ── Step 7: trigger BGV team ─────────────────────────────

    def _trigger_bgv(self, employee: Employee, form: OnboardingForm) -> None:
        """Send the BGV trigger email and start the BGV completion SLA."""
        self.notifications.notify_bgv_trigger(employee, form)
        self.sla.start_timer(form.form_id, SlaStage.BGV_COMPLETION)
        logger.info("BGV process triggered for form %s.", form.form_reference)

    # ── Step 8: monitor & broadcast BGV updates ──────────────

    def record_bgv_update(
        self,
        form: OnboardingForm,
        bgv: BackgroundVerificationTeam,
        response_status: BgvResponseStatus,
        verification_result: VerificationResult,
    ) -> OnboardingForm:
        """Record a BGV team update and notify Employee + PMO (PPT step 8)."""
        if form.form_status not in (FormStatus.APPROVED,):
            raise WorkflowError(
                f"Form {form.form_reference} is not in an approved/BGV state."
            )

        bgv.response_status = response_status
        bgv.verification_result = verification_result
        bgv.last_response_date = _now()
        self.db.commit()

        employee = self.db.get(Employee, form.employee_id)
        self.notifications.notify_bgv_status_update(employee, form, bgv)

        if response_status == BgvResponseStatus.COMPLETED:
            self.sla.complete_timer(form.form_id, SlaStage.BGV_COMPLETION)
            if verification_result == VerificationResult.CLEAR:
                employee.onboarding_status = OnboardingStatus.COMPLETED
            else:
                employee.onboarding_status = OnboardingStatus.ON_HOLD
            self.db.commit()
            logger.info(
                "BGV completed for form %s (result=%s).",
                form.form_reference,
                verification_result.value,
            )
        return form

    # ── Step 10: escalation sweep ────────────────────────────

    def run_escalation_sweep(self) -> int:
        """Detect SLA breaches and send escalation emails. Returns breach count.

        Intended to be invoked periodically by the background scheduler.
        """
        breached = self.sla.find_breached_timers()
        for timer in breached:
            form = self.db.get(OnboardingForm, timer.form_id)
            if form is None:
                continue
            employee = self.db.get(Employee, form.employee_id)
            overdue = self.sla.minutes_overdue(timer)
            self.notifications.notify_escalation(
                employee, form, timer.stage.value, overdue
            )
            self.sla.mark_escalated(timer)
            logger.warning(
                "Escalation raised: form=%s stage=%s overdue=%dm",
                form.form_reference,
                timer.stage.value,
                overdue,
            )
        if breached:
            logger.info("Escalation sweep complete: %d breach(es).", len(breached))
        return len(breached)
