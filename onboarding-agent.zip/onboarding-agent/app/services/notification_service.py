"""Notification service.

Builds notification content for each workflow event, persists a
``NotificationEvent`` record and dispatches it via the EmailService.
Covers PPT workflow steps 6, 8 (status updates) and 10 (escalations).
"""
from __future__ import annotations

from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.logging_config import get_logger
from app.models.entities import (
    BackgroundVerificationTeam,
    Employee,
    NotificationEvent,
    OnboardingForm,
    PMOTeam,
)
from app.models.enums import NotificationChannel, NotificationType
from app.services.email_service import email_service

logger = get_logger(__name__)


class NotificationService:
    """Creates, records and sends notifications to onboarding stakeholders."""

    def __init__(self, db: Session) -> None:
        self.db = db
        self.settings = get_settings()

    # ── internal helpers ─────────────────────────────────────

    def _record_and_send(
        self,
        *,
        notification_type: NotificationType,
        recipients: list[str],
        subject: str,
        body: str,
        cc: list[str] | None = None,
        employee_id: str | None = None,
        form_id: str | None = None,
        html: str | None = None,
    ) -> NotificationEvent:
        cc = cc or []
        event = NotificationEvent(
            employee_id=employee_id,
            form_id=form_id,
            notification_type=notification_type,
            channel=NotificationChannel.EMAIL,
            recipients=",".join(recipients),
            cc_recipients=",".join(cc),
            subject=subject,
            body=body,
        )
        sent = email_service.send(
            to=recipients, subject=subject, body=body, cc=cc, html=html
        )
        event.is_sent = sent
        self.db.add(event)
        self.db.commit()
        self.db.refresh(event)
        logger.info("Notification '%s' recorded (sent=%s).", notification_type, sent)
        return event

    # ── workflow notifications ───────────────────────────────

    def notify_form_returned(
        self, employee: Employee, form: OnboardingForm, missing: list[str]
    ) -> NotificationEvent:
        """Step 4 — mandatory fields missing, form returned to employee."""
        body = (
            f"Hello {employee.employee_name},\n\n"
            f"Your background verification form ({form.form_reference}) could "
            f"not be processed because the following mandatory fields are "
            f"incomplete:\n  - " + "\n  - ".join(missing) + "\n\n"
            "Please complete these fields and resubmit the form.\n\n"
            "— Employee Onboarding AI Agent"
        )
        return self._record_and_send(
            notification_type=NotificationType.FORM_RETURNED,
            recipients=[employee.email],
            subject=f"Action required: complete your BGV form ({form.form_reference})",
            body=body,
            employee_id=employee.employee_id,
            form_id=form.form_id,
        )

    def notify_pmo_submission(
        self, employee: Employee, form: OnboardingForm
    ) -> NotificationEvent:
        """Step 5 — validated form submitted to PMO team for review.

        Email contains every submitted field plus one-click Approve / Reject
        buttons that hit the public PMO action endpoints.
        """
        base = self.settings.app_public_url.rstrip("/")
        approve_url = f"{base}/pmo/forms/{form.form_id}/approve"
        reject_url = f"{base}/pmo/forms/{form.form_id}/reject"

        # Render submitted field values
        fields = sorted(form.fields, key=lambda f: f.field_order)
        text_rows = "\n".join(
            f"  {f.field_label:30s}: {f.field_value or '(blank)'}" for f in fields
        )
        html_rows = "".join(
            f"<tr><td style='padding:6px 12px;border:1px solid #ddd;background:#f7f9fc;"
            f"font-weight:600;'>{f.field_label}</td>"
            f"<td style='padding:6px 12px;border:1px solid #ddd;'>"
            f"{f.field_value or '<i style=\"color:#999;\">(blank)</i>'}</td></tr>"
            for f in fields
        )

        body = (
            f"Hello PMO Team,\n\n"
            f"A background verification form is ready for review.\n\n"
            f"  Employee : {employee.employee_name}\n"
            f"  Form Ref : {form.form_reference}\n"
            f"  Submitted: {form.submitted_date}\n\n"
            f"Submitted details:\n{text_rows}\n\n"
            f"Approve : {approve_url}\n"
            f"Reject  : {reject_url}\n\n"
            "— Employee Onboarding AI Agent"
        )

        html = f"""\
<html><body style="font-family: Arial, sans-serif; color:#222;">
  <h2 style="margin-bottom:4px;">PMO Review Required</h2>
  <p style="color:#666;margin-top:0;">Form <b>{form.form_reference}</b> · submitted {form.submitted_date}</p>

  <h3>Submitted details</h3>
  <table style="border-collapse:collapse;font-size:13px;">{html_rows}</table>

  <p style="margin-top:24px;">
    <a href="{approve_url}"
       style="background:#2ea043;color:#fff;padding:12px 22px;border-radius:6px;
              text-decoration:none;font-weight:600;margin-right:12px;">
      ✓ Approve
    </a>
    <a href="{reject_url}"
       style="background:#d9544f;color:#fff;padding:12px 22px;border-radius:6px;
              text-decoration:none;font-weight:600;">
      ✗ Reject
    </a>
  </p>

  <p style="font-size:11px;color:#999;margin-top:30px;">
    Clicking Reject will prompt you for a reason that is forwarded to the employee for resubmission.
  </p>
</body></html>"""

        return self._record_and_send(
            notification_type=NotificationType.FORM_SUBMITTED,
            recipients=[self.settings.pmo_team_email],
            subject=f"PMO review required: {form.form_reference} — {employee.employee_name}",
            body=body,
            html=html,
            employee_id=employee.employee_id,
            form_id=form.form_id,
        )

    def notify_pmo_decision(
        self, employee: Employee, form: OnboardingForm, approved: bool
    ) -> NotificationEvent:
        """Step 6 — PMO approved or rejected the form."""
        if approved:
            ntype = NotificationType.PMO_APPROVED
            subject = f"BGV form approved ({form.form_reference})"
            body = (
                f"Hello {employee.employee_name},\n\n"
                "Good news — the PMO team has approved your background "
                "verification form. The verification process will now begin.\n\n"
                "— Employee Onboarding AI Agent"
            )
        else:
            ntype = NotificationType.PMO_REJECTED
            subject = f"BGV form rejected ({form.form_reference})"
            comments = form.pmo_reviewer_comments or "No additional comments provided."
            body = (
                f"Hello {employee.employee_name},\n\n"
                "The PMO team has rejected your background verification form.\n\n"
                f"Reviewer comments: {comments}\n\n"
                "Please review the feedback and contact the onboarding team if "
                "you need assistance.\n\n"
                "— Employee Onboarding AI Agent"
            )
        return self._record_and_send(
            notification_type=ntype,
            recipients=[employee.email],
            subject=subject,
            body=body,
            employee_id=employee.employee_id,
            form_id=form.form_id,
        )

    def notify_bgv_trigger(
        self, employee: Employee, form: OnboardingForm
    ) -> NotificationEvent:
        """Step 7 — trigger email to the Background Verification team."""
        body = (
            f"Hello BGV Team,\n\n"
            "Please initiate background verification for the following "
            "approved candidate:\n\n"
            f"  Employee : {employee.employee_name}\n"
            f"  Email    : {employee.email}\n"
            f"  Form Ref : {form.form_reference}\n"
            f"  Dept     : {employee.department or 'N/A'}\n\n"
            "Kindly share status updates as the verification progresses.\n\n"
            "— Employee Onboarding AI Agent"
        )
        return self._record_and_send(
            notification_type=NotificationType.BGV_TRIGGERED,
            recipients=[self.settings.bgv_team_email],
            subject=f"Background verification request: {form.form_reference}",
            body=body,
            employee_id=employee.employee_id,
            form_id=form.form_id,
        )

    def notify_bgv_status_update(
        self,
        employee: Employee,
        form: OnboardingForm,
        bgv: BackgroundVerificationTeam,
    ) -> list[NotificationEvent]:
        """Step 8 — status update sent to both Employee and PMO team."""
        summary = (
            f"  Form Ref           : {form.form_reference}\n"
            f"  Verification status: {bgv.response_status.value}\n"
            f"  Result             : {bgv.verification_result.value}\n"
            f"  Last update        : {bgv.last_response_date}\n"
        )
        events: list[NotificationEvent] = []

        events.append(
            self._record_and_send(
                notification_type=NotificationType.BGV_STATUS_UPDATE,
                recipients=[employee.email],
                subject=f"Verification status update ({form.form_reference})",
                body=(
                    f"Hello {employee.employee_name},\n\n"
                    "Here is the latest update on your background "
                    f"verification:\n\n{summary}\n"
                    "— Employee Onboarding AI Agent"
                ),
                employee_id=employee.employee_id,
                form_id=form.form_id,
            )
        )
        events.append(
            self._record_and_send(
                notification_type=NotificationType.BGV_STATUS_UPDATE,
                recipients=[self.settings.pmo_team_email],
                subject=f"BGV status update for {employee.employee_name}",
                body=(
                    f"Hello PMO Team,\n\n"
                    f"Verification status update for {employee.employee_name}:\n\n"
                    f"{summary}\n— Employee Onboarding AI Agent"
                ),
                employee_id=employee.employee_id,
                form_id=form.form_id,
            )
        )
        return events

    def notify_escalation(
        self,
        employee: Employee,
        form: OnboardingForm,
        stage: str,
        minutes_overdue: int,
    ) -> NotificationEvent:
        """Step 10 — SLA breach escalation to PMO + BGV, Employee on CC."""
        body = (
            "Hello,\n\n"
            "An SLA breach has been detected in the onboarding workflow and "
            "requires attention.\n\n"
            f"  Employee   : {employee.employee_name}\n"
            f"  Form Ref   : {form.form_reference}\n"
            f"  Stage      : {stage}\n"
            f"  Overdue by : {minutes_overdue} minute(s)\n\n"
            "Please action the pending step at the earliest to keep the "
            "onboarding on track.\n\n"
            "— Employee Onboarding AI Agent (automated escalation)"
        )
        return self._record_and_send(
            notification_type=NotificationType.ESCALATION,
            recipients=[self.settings.pmo_team_email, self.settings.bgv_team_email],
            cc=[employee.email],
            subject=f"[ESCALATION] SLA breach — {stage} ({form.form_reference})",
            body=body,
            employee_id=employee.employee_id,
            form_id=form.form_id,
        )
