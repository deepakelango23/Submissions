"""Form service.

Owns the lifecycle of an ``OnboardingForm``: provisioning fields from the
template, accepting employee submissions, and running the validation pass
described in PPT workflow step 4 (missing-mandatory-field check + per-field
rule validation).
"""
from __future__ import annotations

import re
import uuid
from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.core.logging_config import get_logger
from app.models.entities import Employee, FormField, OnboardingForm
from app.models.enums import FormStatus, ValidationStatus
from app.models.schemas import FieldValueIn, ValidationResult
from app.services.form_template import FORM_FIELD_TEMPLATE

logger = get_logger(__name__)

_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
_PHONE_RE = re.compile(r"^\+?[0-9\s\-]{7,15}$")


def _now() -> datetime:
    return datetime.now(timezone.utc)


class FormService:
    """Create, populate and validate background verification forms."""

    def __init__(self, db: Session) -> None:
        self.db = db

    # ── creation ─────────────────────────────────────────────

    def create_form(self, employee: Employee) -> OnboardingForm:
        """Provision a new BGV form with all template fields (PPT step 2).

        Each field is pre-populated from the employee record so that the data
        captured during Excel upload flows straight into the BGV form (and
        into the PMO review email).
        """
        form = OnboardingForm(
            form_reference=f"BGV-{uuid.uuid4().hex[:8].upper()}",
            employee_id=employee.employee_id,
            form_status=FormStatus.DRAFT,
            validation_status=ValidationStatus.PENDING,
        )
        self.db.add(form)
        self.db.flush()  # assign form_id

        prefill = {
            "Emp # / Talent ID": employee.talent_id,
            "Emp Name": employee.employee_name,
            "Emp Type": employee.emp_type,
            "Account Name": employee.account_name,
            "Account Focal email": employee.account_focal_email,
            "Project ID": employee.project_id,
            "Project Name": employee.project_name,
        }

        for order, tpl in enumerate(FORM_FIELD_TEMPLATE):
            value = prefill.get(tpl["field_label"])
            self.db.add(
                FormField(
                    form_id=form.form_id,
                    field_label=tpl["field_label"],
                    field_type=tpl["field_type"],
                    is_mandatory=tpl["is_mandatory"],
                    validation_rule=tpl["validation_rule"],
                    section=tpl["section"],
                    field_order=order,
                    field_value=value,
                    is_filled=bool(value and str(value).strip()),
                )
            )
        self.db.commit()
        self.db.refresh(form)
        logger.info(
            "Form %s created for employee %s.", form.form_reference, employee.email
        )
        return form

    # ── submission ───────────────────────────────────────────

    def apply_values(
        self, form: OnboardingForm, values: list[FieldValueIn]
    ) -> OnboardingForm:
        """Apply employee-supplied values to the form's fields."""
        by_id = {f.field_id: f for f in form.fields}
        for item in values:
            field = by_id.get(item.field_id)
            if field is None:
                logger.warning(
                    "Submitted value for unknown field_id=%s ignored.", item.field_id
                )
                continue
            field.field_value = item.value
            field.is_filled = bool(item.value and str(item.value).strip())

        form.form_status = FormStatus.SUBMITTED
        form.submitted_date = _now()
        form.last_updated_date = _now()
        self.db.commit()
        self.db.refresh(form)
        return form

    # ── validation (PPT workflow step 4) ─────────────────────

    def _validate_field(self, field: FormField) -> str | None:
        """Return an error label if the field's value violates its rule."""
        value = (field.field_value or "").strip()
        rule = field.validation_rule or "non_empty"

        if not value:
            # Empty value is only an error for mandatory fields; the caller
            # already separates missing mandatory fields, so skip here.
            return None

        if rule == "email" and not _EMAIL_RE.match(value):
            return f"{field.field_label} (invalid email format)"
        if rule == "phone" and not _PHONE_RE.match(value):
            return f"{field.field_label} (invalid phone number)"
        if rule == "number" and not value.replace(".", "", 1).isdigit():
            return f"{field.field_label} (must be numeric)"
        if rule == "date":
            try:
                datetime.fromisoformat(value)
            except ValueError:
                return f"{field.field_label} (invalid date, use YYYY-MM-DD)"
        if rule == "checkbox_true" and value.lower() not in ("true", "yes", "1"):
            return f"{field.field_label} (consent must be given)"
        return None

    def validate_form(self, form: OnboardingForm) -> ValidationResult:
        """Run the full validation pass for a submitted form.

        Implements PPT step 4:
          * missing mandatory fields  -> form returned to employee
          * all required fields valid -> proceed to PMO submission
        """
        missing: list[str] = []
        invalid: list[str] = []

        for field in form.fields:
            if field.is_mandatory and not field.is_filled:
                missing.append(field.field_label)
                continue
            err = self._validate_field(field)
            if err:
                invalid.append(err)

        is_valid = not missing and not invalid

        if is_valid:
            form.validation_status = ValidationStatus.PASS
            form.form_status = FormStatus.UNDER_REVIEW
            form.missing_field_list = []
            message = "All mandatory fields are complete and valid."
        else:
            form.validation_status = ValidationStatus.FAIL
            form.form_status = FormStatus.INCOMPLETE
            form.missing_field_list = missing + invalid
            message = (
                "Form is incomplete. Please correct the highlighted fields "
                "and resubmit."
            )

        form.last_updated_date = _now()
        self.db.commit()
        self.db.refresh(form)

        logger.info(
            "Form %s validated: status=%s missing=%d invalid=%d",
            form.form_reference,
            form.validation_status.value,
            len(missing),
            len(invalid),
        )
        return ValidationResult(
            is_valid=is_valid,
            validation_status=form.validation_status,
            missing_fields=missing,
            invalid_fields=invalid,
            message=message,
        )

    # ── lookup helpers ───────────────────────────────────────

    def get_form(self, form_id: str) -> OnboardingForm | None:
        return self.db.get(OnboardingForm, form_id)

    def get_active_form_for_employee(
        self, employee_id: str
    ) -> OnboardingForm | None:
        """Return the most recent non-completed form for an employee."""
        return (
            self.db.query(OnboardingForm)
            .filter(OnboardingForm.employee_id == employee_id)
            .order_by(OnboardingForm.created_at.desc())
            .first()
        )
