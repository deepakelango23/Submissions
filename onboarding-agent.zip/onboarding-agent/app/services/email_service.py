"""Email delivery service.

Sends notification and escalation emails. When ``SMTP_ENABLED`` is false the
service logs the message instead of dispatching it, so the application is fully
runnable for local development and demos without a mail server.
"""
from __future__ import annotations

import smtplib
from email.message import EmailMessage

from app.core.config import get_settings
from app.core.logging_config import get_logger

logger = get_logger(__name__)


class EmailService:
    """Thin wrapper around SMTP with a log-only fallback."""

    def __init__(self) -> None:
        self.settings = get_settings()

    def send(
        self,
        *,
        to: list[str],
        subject: str,
        body: str,
        cc: list[str] | None = None,
        html: str | None = None,
    ) -> bool:
        """Send an email. Returns True on success (or log-only delivery).

        If ``html`` is provided it is sent as the HTML alternative; ``body``
        remains the plain-text fallback.
        """
        cc = cc or []
        recipients = [r for r in to if r]
        cc_list = [c for c in cc if c]

        if not recipients:
            logger.warning("Email '%s' has no recipients — skipped.", subject)
            return False

        if not self.settings.smtp_enabled:
            logger.info(
                "[EMAIL · log-only] to=%s cc=%s subject=%s\n%s",
                recipients,
                cc_list,
                subject,
                body,
            )
            return True

        try:
            msg = EmailMessage()
            msg["From"] = self.settings.smtp_from or self.settings.smtp_username
            msg["To"] = ", ".join(recipients)
            if cc_list:
                msg["Cc"] = ", ".join(cc_list)
            msg["Subject"] = subject
            msg.set_content(body)
            if html:
                msg.add_alternative(html, subtype="html")

            with smtplib.SMTP(
                self.settings.smtp_host, self.settings.smtp_port, timeout=15
            ) as server:
                server.starttls()
                if self.settings.smtp_username:
                    server.login(
                        self.settings.smtp_username, self.settings.smtp_password
                    )
                server.send_message(msg, to_addrs=recipients + cc_list)
            logger.info("Email sent: '%s' -> %s", subject, recipients)
            return True
        except Exception as exc:  # noqa: BLE001
            logger.error("Failed to send email '%s': %s", subject, exc)
            return False


# Module-level singleton for convenient import.
email_service = EmailService()
