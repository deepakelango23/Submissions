"""Knowledge base service (PPT workflow step 9).

Loads the FAQ repository and answers general onboarding queries — system
access information, contact details and process questions — using a simple
keyword-overlap scorer. The repository is plain JSON so it can be maintained
without code changes.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from app.core.logging_config import get_logger

logger = get_logger(__name__)

_KB_PATH = Path(__file__).resolve().parents[2] / "data" / "knowledge_base" / "faqs.json"
_STOPWORDS = {
    "the", "a", "an", "is", "are", "do", "does", "i", "my", "me", "to", "for",
    "of", "and", "or", "in", "on", "what", "how", "who", "can", "you", "with",
}


class KnowledgeBaseService:
    """Keyword-based FAQ retrieval over the onboarding knowledge base."""

    def __init__(self, kb_path: Path | None = None) -> None:
        self.kb_path = kb_path or _KB_PATH
        self._faqs: list[dict] = []
        self._load()

    def _load(self) -> None:
        try:
            with open(self.kb_path, encoding="utf-8") as fh:
                self._faqs = json.load(fh).get("faqs", [])
            logger.info("Knowledge base loaded: %d FAQ entries.", len(self._faqs))
        except (OSError, json.JSONDecodeError) as exc:
            logger.error("Failed to load knowledge base: %s", exc)
            self._faqs = []

    @staticmethod
    def _tokenize(text: str) -> set[str]:
        words = re.findall(r"[a-z0-9]+", text.lower())
        return {w for w in words if w not in _STOPWORDS and len(w) > 1}

    def search(self, query: str, top_k: int = 1) -> list[dict]:
        """Return the best-matching FAQ entries for a free-text query."""
        q_tokens = self._tokenize(query)
        if not q_tokens or not self._faqs:
            return []

        scored: list[tuple[float, dict]] = []
        for faq in self._faqs:
            keyword_tokens = set(faq.get("keywords", []))
            question_tokens = self._tokenize(faq.get("question", ""))
            # Keyword hits are weighted higher than incidental question overlap.
            score = 2 * len(q_tokens & keyword_tokens) + len(q_tokens & question_tokens)
            if score > 0:
                scored.append((score, faq))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [faq for _, faq in scored[:top_k]]

    def answer(self, query: str) -> str | None:
        """Return the answer text of the single best FAQ match, if any."""
        matches = self.search(query, top_k=1)
        return matches[0]["answer"] if matches else None

    def all_questions(self) -> list[str]:
        """Return every FAQ question — useful for a 'help' / suggestions reply."""
        return [faq["question"] for faq in self._faqs]


# Module-level singleton — the KB is read-only at runtime.
knowledge_base = KnowledgeBaseService()
