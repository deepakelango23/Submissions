"""Excel file processing service for onboarding data."""
from __future__ import annotations

import logging
from io import BytesIO
from typing import Any

import pandas as pd
from pydantic import ValidationError
from sqlalchemy.orm import Session

from app.models.entities import Employee
from app.models.schemas import ExcelEmployeeRow

logger = logging.getLogger(__name__)


class ExcelValidationError(Exception):
    """Raised when Excel validation fails."""
    pass


class ExcelService:
    """Service for processing Excel files with employee onboarding data."""

    # Exact column set defined by data/onboarding_template.xlsx.
    # Uploads with any column outside this set are rejected.
    ALLOWED_COLUMNS = [
        "Emp # / Talent ID",
        "Emp Name",
        "Emp Type",
        "Account Name",
        "Account Focal\nemail",
        "Project ID",
        "Project Name",
        "Project Dept Code",
        "Account ID",
        "DOU Number",
        "Date\nRequested",
    ]

    # Subset of ALLOWED_COLUMNS that must be present and non-empty in every row.
    MANDATORY_FIELDS = [
        "Emp # / Talent ID",
        "Emp Name",
        "Emp Type",
        "Account Name",
        "Account Focal\nemail",
        "Project ID",
        "Project Name",
    ]

    @staticmethod
    def _display(col: str) -> str:
        return col.replace("\n", " ")
    
    def __init__(self, db: Session):
        self.db = db
    
    def validate_and_parse_excel(
        self, file_content: bytes, filename: str
    ) -> list[ExcelEmployeeRow]:
        """
        Validate and parse Excel file content.
        
        Args:
            file_content: Raw bytes of the Excel file
            filename: Name of the uploaded file
            
        Returns:
            List of validated ExcelEmployeeRow objects
            
        Raises:
            ExcelValidationError: If validation fails
        """
        try:
            # Read Excel file
            df = pd.read_excel(BytesIO(file_content))
            logger.info(f"Read Excel file '{filename}' with {len(df)} rows")
            
            # Check if file is empty
            if df.empty:
                raise ExcelValidationError("Excel file is empty")
            
            # Reject any column that isn't part of the onboarding template.
            unexpected_columns = [
                str(col) for col in df.columns if str(col) not in self.ALLOWED_COLUMNS
            ]
            if unexpected_columns:
                raise ExcelValidationError(
                    "Unexpected columns not allowed by onboarding template: "
                    + ", ".join(self._display(c) for c in unexpected_columns)
                )

            # Validate mandatory columns exist
            missing_columns = [col for col in self.MANDATORY_FIELDS if col not in df.columns]
            if missing_columns:
                raise ExcelValidationError(
                    "Missing mandatory columns: "
                    + ", ".join(self._display(c) for c in missing_columns)
                )
            
            # Validate each row
            validated_rows: list[ExcelEmployeeRow] = []
            errors: list[str] = []
            
            for idx_val, row in df.iterrows():
                row_num = 2  # Default to row 2
                try:
                    row_num = int(str(idx_val)) + 2  # +2 because Excel is 1-indexed and has header row
                except (ValueError, TypeError):
                    pass
                
                # Check mandatory fields are not empty
                empty_fields = []
                for field in self.MANDATORY_FIELDS:
                    value = row.get(field)
                    # Check if value is NaN or empty string
                    try:
                        is_na = bool(pd.isna(value))
                    except (TypeError, ValueError):
                        is_na = value is None
                    
                    if is_na:
                        empty_fields.append(field)
                    elif isinstance(value, str) and not value.strip():
                        empty_fields.append(field)
                
                if empty_fields:
                    errors.append(
                        f"Row {row_num}: Missing mandatory fields: "
                        + ", ".join(self._display(c) for c in empty_fields)
                    )
                    continue
                
                # Convert row to dict and validate with Pydantic. Pandas
                # represents blank cells as NaN floats, which Pydantic's
                # str|None types reject — normalise those to None first.
                try:
                    row_dict = {
                        k: (None if pd.isna(v) else v) for k, v in row.to_dict().items()
                    }
                    employee_row = ExcelEmployeeRow(**row_dict)
                    validated_rows.append(employee_row)
                except ValidationError as e:
                    error_details = "; ".join([f"{err['loc'][0]}: {err['msg']}" for err in e.errors()])
                    errors.append(f"Row {row_num}: {error_details}")
            
            # If there are any errors, raise them all
            if errors:
                raise ExcelValidationError(
                    f"Validation failed for {len(errors)} row(s):\n" + "\n".join(errors)
                )
            
            logger.info(f"Successfully validated {len(validated_rows)} rows from Excel")
            return validated_rows
            
        except pd.errors.EmptyDataError:
            raise ExcelValidationError("Excel file is empty or corrupted")
        except Exception as e:
            if isinstance(e, ExcelValidationError):
                raise
            logger.error(f"Error processing Excel file: {e}")
            raise ExcelValidationError(f"Failed to process Excel file: {str(e)}")
    
    def check_duplicate_talent_ids(
        self, rows: list[ExcelEmployeeRow]
    ) -> dict[str, list[str]]:
        """
        Check for duplicate Talent IDs in the Excel and against the database.
        
        Returns:
            Dict with 'excel_duplicates' and 'db_duplicates' lists
        """
        talent_ids = [row.talent_id for row in rows]
        
        # Check for duplicates within the Excel file
        excel_duplicates = [tid for tid in set(talent_ids) if talent_ids.count(tid) > 1]
        
        # Check for duplicates in the database
        existing_talent_ids = (
            self.db.query(Employee.talent_id)
            .filter(Employee.talent_id.in_(talent_ids))
            .all()
        )
        db_duplicates = [tid[0] for tid in existing_talent_ids]
        
        return {
            "excel_duplicates": excel_duplicates,
            "db_duplicates": db_duplicates,
        }
    
    def create_employees_from_excel(
        self, rows: list[ExcelEmployeeRow], skip_duplicates: bool = False
    ) -> dict[str, Any]:
        """
        Create employee records from validated Excel rows.
        
        Args:
            rows: List of validated ExcelEmployeeRow objects
            skip_duplicates: If True, skip rows with duplicate Talent IDs
            
        Returns:
            Dict with 'created', 'skipped', and 'errors' counts
        """
        duplicates = self.check_duplicate_talent_ids(rows)
        
        if not skip_duplicates and (duplicates["excel_duplicates"] or duplicates["db_duplicates"]):
            raise ExcelValidationError(
                f"Duplicate Talent IDs found. "
                f"Excel duplicates: {duplicates['excel_duplicates']}, "
                f"Database duplicates: {duplicates['db_duplicates']}"
            )
        
        created = 0
        skipped = 0
        errors = []
        created_employees = []
        
        for row in rows:
            # Skip if duplicate and skip_duplicates is True
            if skip_duplicates and (
                row.talent_id in duplicates["excel_duplicates"]
                or row.talent_id in duplicates["db_duplicates"]
            ):
                skipped += 1
                logger.info(f"Skipped duplicate Talent ID: {row.talent_id}")
                continue
            
            try:
                employee = Employee(
                    talent_id=row.talent_id,
                    employee_name=row.employee_name,
                    project_id=row.project_id,
                    account_focal_email=row.account_focal_email,
                    emp_type=row.emp_type,
                    account_name=row.account_name,
                    project_name=row.project_name,
                    project_dept_code=row.project_dept_code,
                    account_id=row.account_id,
                    dou_number=row.dou_number,
                    date_requested=row.date_requested,
                    email=row.account_focal_email,  # Use account focal email as primary email
                )
                self.db.add(employee)
                self.db.flush()  # Flush to get the employee_id
                created_employees.append({
                    "employee_id": employee.employee_id,
                    "talent_id": employee.talent_id,
                    "employee_name": employee.employee_name
                })
                created += 1
                logger.info(f"Created employee: {row.talent_id} - {row.employee_name}")
            except Exception as e:
                errors.append(f"Failed to create employee {row.talent_id}: {str(e)}")
                logger.error(f"Error creating employee {row.talent_id}: {e}")
        
        if created > 0:
            self.db.commit()
            logger.info(f"Successfully created {created} employees from Excel")
        
        return {
            "created": created,
            "skipped": skipped,
            "errors": errors,
            "duplicates": duplicates,
            "created_employees": created_employees,
        }

# Made with Bob
