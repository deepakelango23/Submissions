"""SLA service.

Manages SLA timers for each workflow stage and detects breaches. SLA target
durations are configuration-driven (``SLA_*`` env vars). Per the PPT note,
these timelines are design-only values used to exercise the escalation logic.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.logging_config import get_logger
from app.models.entities import SlaTimer
from app.models.enums import SlaStage

logger = get_logger(__name__)


def _now() -> datetime:
    return datetime.now(timezone.utc)


class SlaService:
    """Start, complete and evaluate SLA timers for onboarding stages."""

    def __init__(self, db: Session) -> None:
        self.db = db
        self.settings = get_settings()

    def _duration_for(self, stage: SlaStage) -> timedelta:
        mapping = {
            SlaStage.FORM_VALIDATION: self.settings.sla_form_validation_min,
            SlaStage.PMO_REVIEW: self.settings.sla_pmo_review_min,
            SlaStage.BGV_COMPLETION: self.settings.sla_bgv_completion_min,
        }
        return timedelta(minutes=mapping[stage])

    # ── timer lifecycle ──────────────────────────────────────

    def start_timer(self, form_id: str, stage: SlaStage) -> SlaTimer:
        """Start (or restart) an SLA timer for a workflow stage."""
        existing = self._get_open_timer(form_id, stage)
        if existing:
            logger.info(
                "SLA timer for %s/%s already open — reusing.", form_id, stage.value
            )
            return existing

        started = _now()
        timer = SlaTimer(
            form_id=form_id,
            stage=stage,
            started_at=started,
            due_at=started + self._duration_for(stage),
        )
        self.db.add(timer)
        self.db.commit()
        self.db.refresh(timer)
        logger.info(
            "SLA timer started: form=%s stage=%s due_at=%s",
            form_id,
            stage.value,
            timer.due_at,
        )
        return timer

    def complete_timer(self, form_id: str, stage: SlaStage) -> SlaTimer | None:
        """Mark the open timer for a stage as completed (stops the clock)."""
        timer = self._get_open_timer(form_id, stage)
        if timer is None:
            return None
        timer.completed_at = _now()
        self.db.commit()
        self.db.refresh(timer)
        logger.info("SLA timer completed: form=%s stage=%s", form_id, stage.value)
        return timer

    # ── breach detection (PPT workflow step 10) ──────────────

    def find_breached_timers(self) -> list[SlaTimer]:
        """Return open, un-escalated timers whose deadline has passed."""
        now = _now()
        timers = (
            self.db.query(SlaTimer)
            .filter(
                SlaTimer.completed_at.is_(None),
                SlaTimer.escalated.is_(False),
                SlaTimer.due_at < now,
            )
            .all()
        )
        for t in timers:
            t.is_breached = True
        if timers:
            self.db.commit()
        return timers

    def minutes_overdue(self, timer: SlaTimer) -> int:
        delta = _now() - timer.due_at
        return max(0, int(delta.total_seconds() // 60))

    def mark_escalated(self, timer: SlaTimer) -> None:
        timer.escalated = True
        timer.is_breached = True
        self.db.commit()

    # ── helpers ──────────────────────────────────────────────

    def _get_open_timer(self, form_id: str, stage: SlaStage) -> SlaTimer | None:
        return (
            self.db.query(SlaTimer)
            .filter(
                SlaTimer.form_id == form_id,
                SlaTimer.stage == stage,
                SlaTimer.completed_at.is_(None),
            )
            .first()
        )
