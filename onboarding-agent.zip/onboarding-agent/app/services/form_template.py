"""Default BGV form field template.

Defines the set of fields the agent provisions whenever a new background
verification form is created. The form mirrors the seven mandatory
attributes captured in ``data/onboarding_template.xlsx``.
"""
from app.models.enums import FieldSection, FieldType

# Each entry: label, type, mandatory, section, validation_rule
FORM_FIELD_TEMPLATE: list[dict] = [
    {
        "field_label": "Emp # / Talent ID",
        "field_type": FieldType.TEXT,
        "is_mandatory": True,
        "section": FieldSection.IDENTITY,
        "validation_rule": "non_empty",
    },
    {
        "field_label": "Emp Name",
        "field_type": FieldType.TEXT,
        "is_mandatory": True,
        "section": FieldSection.IDENTITY,
        "validation_rule": "non_empty",
    },
    {
        "field_label": "Emp Type",
        "field_type": FieldType.TEXT,
        "is_mandatory": True,
        "section": FieldSection.EMPLOYMENT,
        "validation_rule": "non_empty",
    },
    {
        "field_label": "Account Name",
        "field_type": FieldType.TEXT,
        "is_mandatory": True,
        "section": FieldSection.EMPLOYMENT,
        "validation_rule": "non_empty",
    },
    {
        "field_label": "Account Focal email",
        "field_type": FieldType.EMAIL,
        "is_mandatory": True,
        "section": FieldSection.EMPLOYMENT,
        "validation_rule": "email",
    },
    {
        "field_label": "Project ID",
        "field_type": FieldType.TEXT,
        "is_mandatory": True,
        "section": FieldSection.EMPLOYMENT,
        "validation_rule": "non_empty",
    },
    {
        "field_label": "Project Name",
        "field_type": FieldType.TEXT,
        "is_mandatory": True,
        "section": FieldSection.EMPLOYMENT,
        "validation_rule": "non_empty",
    },
]
