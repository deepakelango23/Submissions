"""Background scheduler.

Runs the SLA escalation sweep on a fixed interval (PPT workflow step 10 —
delay handling). Uses APScheduler so the sweep runs independently of any
incoming HTTP request.
"""
from __future__ import annotations

from apscheduler.schedulers.background import BackgroundScheduler

from app.core.config import get_settings
from app.core.database import SessionLocal
from app.core.logging_config import get_logger
from app.services.workflow import WorkflowOrchestrator

logger = get_logger(__name__)

_scheduler: BackgroundScheduler | None = None


def _escalation_job() -> None:
    """Scheduled job: open a session, run the escalation sweep, close it."""
    db = SessionLocal()
    try:
        orchestrator = WorkflowOrchestrator(db)
        count = orchestrator.run_escalation_sweep()
        if count:
            logger.warning("Escalation job raised %d escalation(s).", count)
    except Exception as exc:  # noqa: BLE001
        logger.error("Escalation job failed: %s", exc)
    finally:
        db.close()


def start_scheduler() -> BackgroundScheduler:
    """Start the background scheduler and register the escalation sweep."""
    global _scheduler
    if _scheduler is not None:
        return _scheduler

    settings = get_settings()
    _scheduler = BackgroundScheduler(daemon=True)
    _scheduler.add_job(
        _escalation_job,
        trigger="interval",
        minutes=settings.sla_monitor_interval_min,
        id="sla_escalation_sweep",
        replace_existing=True,
    )
    _scheduler.start()
    logger.info(
        "Scheduler started — escalation sweep every %d minute(s).",
        settings.sla_monitor_interval_min,
    )
    return _scheduler


def shutdown_scheduler() -> None:
    """Stop the background scheduler on application shutdown."""
    global _scheduler
    if _scheduler is not None:
        _scheduler.shutdown(wait=False)
        _scheduler = None
        logger.info("Scheduler stopped.")
