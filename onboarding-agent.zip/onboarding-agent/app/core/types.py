"""Custom SQLAlchemy type for storing Python ``str`` enums.

Storing enums in a plain ``String`` column persists the value but returns a
plain string on read, so attribute access like ``status.value`` fails. This
``TypeDecorator`` stores the enum's ``.value`` and rehydrates the proper enum
member when the row is loaded.
"""
from __future__ import annotations

from enum import Enum
from typing import Type

from sqlalchemy import String
from sqlalchemy.types import TypeDecorator


class EnumType(TypeDecorator):
    """Persist a str-Enum as its value and load it back as the enum member."""

    impl = String
    cache_ok = True

    def __init__(self, enum_cls: Type[Enum], length: int = 40, **kwargs) -> None:
        self.enum_cls = enum_cls
        super().__init__(length=length, **kwargs)

    def process_bind_param(self, value, dialect):  # write
        if value is None:
            return None
        if isinstance(value, self.enum_cls):
            return value.value
        # Allow passing a raw string that is a valid member value.
        return self.enum_cls(value).value

    def process_result_value(self, value, dialect):  # read
        if value is None:
            return None
        return self.enum_cls(value)
