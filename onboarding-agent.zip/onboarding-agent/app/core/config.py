"""Application configuration, loaded from environment / .env file."""
from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # Application
    app_name: str = "Employee Onboarding AI Agent"
    app_env: str = "development"
    app_host: str = "0.0.0.0"
    app_port: int = 8000

    # Database
    database_url: str = "sqlite:///./data/onboarding.db"

    # Prerequisite recipients
    pmo_team_email: str = "pmo-team@example.com"
    bgv_team_email: str = "bgv-team@example.com"

    # Public base URL — used to build clickable links in outgoing emails
    app_public_url: str = "http://127.0.0.1:8000"

    # SMTP
    smtp_enabled: bool = False
    smtp_host: str = "smtp.example.com"
    smtp_port: int = 587
    smtp_username: str = ""
    smtp_password: str = ""
    smtp_from: str = "onboarding-agent@example.com"

    # SLA targets (minutes) — design-only
    sla_form_validation_min: int = 5
    sla_pmo_review_min: int = 1440
    sla_bgv_completion_min: int = 7200
    sla_monitor_interval_min: int = 15

@lru_cache
def get_settings() -> Settings:
    """Return a cached Settings instance."""
    return Settings()
