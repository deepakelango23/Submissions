"""End-to-end tests for the onboarding workflow.

Each test exercises a slice of the PPT workflow against an in-memory SQLite
database, so the suite runs fast and needs no external services.
"""
import os
import sys

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# Ensure the project root is importable when pytest is run from anywhere.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.core.database import Base  # noqa: E402
from app.agent.intents import Intent, detect_intent  # noqa: E402
from app.agent.onboarding_agent import OnboardingAgent  # noqa: E402
from app.models.entities import Employee  # noqa: E402
from app.models.enums import (  # noqa: E402
    BgvResponseStatus,
    FormStatus,
    OnboardingStatus,
    PmoApprovalStatus,
    ValidationStatus,
    VerificationResult,
)
from app.models.schemas import FieldValueIn  # noqa: E402
from app.services.knowledge_base import knowledge_base  # noqa: E402
from app.services.workflow import WorkflowOrchestrator  # noqa: E402


@pytest.fixture()
def db():
    """Fresh in-memory database per test."""
    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, expire_on_commit=False)
    session = Session()
    yield session
    session.close()


@pytest.fixture()
def employee(db):
    emp = Employee(employee_name="Test User", email="test.user@example.com")
    db.add(emp)
    db.commit()
    db.refresh(emp)
    return emp


def _value_for(field):
    """Return a value that satisfies the field's validation_rule."""
    rule = field.validation_rule or "non_empty"
    return {
        "email": "ref@example.com",
        "phone": "+919000000000",
        "number": "5",
        "date": "1995-06-15",
        "checkbox_true": "true",
        "non_empty": "Sample value",
    }.get(rule, "Sample value")


def _complete_values(form, drop_first=False):
    """Build values for all mandatory fields; optionally skip the first."""
    values = []
    mandatory = [f for f in form.fields if f.is_mandatory]
    for i, f in enumerate(mandatory):
        if drop_first and i == 0:
            continue
        values.append(FieldValueIn(field_id=f.field_id, value=_value_for(f)))
    return values


# ── workflow steps 1-2 ───────────────────────────────────────


def test_request_form_creates_form_with_fields(db, employee):
    wf = WorkflowOrchestrator(db)
    form = wf.request_form(employee)
    assert form.form_reference.startswith("BGV-")
    assert len(form.fields) > 0
    assert employee.onboarding_status == OnboardingStatus.IN_PROGRESS


def test_request_form_is_idempotent(db, employee):
    wf = WorkflowOrchestrator(db)
    first = wf.request_form(employee)
    second = wf.request_form(employee)
    assert first.form_id == second.form_id


# ── workflow step 4 — validation ─────────────────────────────


def test_submit_form_missing_fields_returns_to_employee(db, employee):
    wf = WorkflowOrchestrator(db)
    form = wf.request_form(employee)
    result = wf.submit_form(form, _complete_values(form, drop_first=True))
    assert result.is_valid is False
    assert result.validation_status == ValidationStatus.FAIL
    assert len(result.missing_fields) >= 1
    assert form.form_status == FormStatus.INCOMPLETE


def test_submit_complete_form_passes_validation(db, employee):
    wf = WorkflowOrchestrator(db)
    form = wf.request_form(employee)
    result = wf.submit_form(form, _complete_values(form))
    assert result.is_valid is True
    assert result.validation_status == ValidationStatus.PASS
    assert form.form_status == FormStatus.UNDER_REVIEW


def test_invalid_email_fails_validation(db, employee):
    wf = WorkflowOrchestrator(db)
    form = wf.request_form(employee)
    values = _complete_values(form)
    # Corrupt the first EMAIL field with a bad value.
    for v in values:
        field = next(f for f in form.fields if f.field_id == v.field_id)
        if field.field_type.value == "EMAIL":
            v.value = "not-an-email"
            break
    result = wf.submit_form(form, values)
    assert result.is_valid is False
    assert any("email" in inv.lower() for inv in result.invalid_fields)


# ── workflow steps 5-7 — PMO review & BGV trigger ────────────


def test_pmo_approval_advances_to_bgv(db, employee):
    wf = WorkflowOrchestrator(db)
    form = wf.request_form(employee)
    wf.submit_form(form, _complete_values(form))
    updated = wf.pmo_review(form, PmoApprovalStatus.APPROVED, "Reviewer", "ok")
    assert updated.pmo_approval_status == PmoApprovalStatus.APPROVED
    assert updated.form_status == FormStatus.APPROVED


def test_pmo_rejection_holds_onboarding(db, employee):
    wf = WorkflowOrchestrator(db)
    form = wf.request_form(employee)
    wf.submit_form(form, _complete_values(form))
    updated = wf.pmo_review(form, PmoApprovalStatus.REJECTED, "Reviewer", "no")
    assert updated.form_status == FormStatus.REJECTED
    assert employee.onboarding_status == OnboardingStatus.ON_HOLD


# ── workflow step 8 — BGV updates ────────────────────────────


def test_bgv_completion_clear_completes_onboarding(db, employee):
    from app.models.entities import BackgroundVerificationTeam

    wf = WorkflowOrchestrator(db)
    form = wf.request_form(employee)
    wf.submit_form(form, _complete_values(form))
    wf.pmo_review(form, PmoApprovalStatus.APPROVED, "Reviewer", "ok")

    bgv = BackgroundVerificationTeam(
        bv_team_name="BGV", bv_email_id="bgv@example.com"
    )
    db.add(bgv)
    db.commit()

    wf.record_bgv_update(
        form, bgv, BgvResponseStatus.COMPLETED, VerificationResult.CLEAR
    )
    assert employee.onboarding_status == OnboardingStatus.COMPLETED


# ── intent detection ─────────────────────────────────────────


@pytest.mark.parametrize(
    "message,expected",
    [
        ("I need the verification form", Intent.REQUEST_FORM),
        ("what is the status of my onboarding?", Intent.CHECK_STATUS),
        ("how long does onboarding take?", Intent.FAQ_QUERY),
        ("hello", Intent.GREETING),
        ("help", Intent.HELP),
    ],
)
def test_intent_detection(message, expected):
    assert detect_intent(message) == expected


# ── knowledge base (workflow step 9) ─────────────────────────


def test_knowledge_base_answers_access_question():
    answer = knowledge_base.answer("how do I get system access?")
    assert answer is not None
    assert len(answer) > 10


def test_knowledge_base_returns_none_for_irrelevant_query():
    assert knowledge_base.answer("zxqw random gibberish text") is None


# ── agent integration ────────────────────────────────────────


def test_agent_request_form_via_chat(db, employee):
    agent = OnboardingAgent(db)
    resp = agent.handle_message(
        "Please share the BGV form", employee_id=employee.employee_id
    )
    assert resp.intent == Intent.REQUEST_FORM.value
    assert resp.data is not None
    assert "form_id" in resp.data
