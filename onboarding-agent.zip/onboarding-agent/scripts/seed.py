"""Seed script.

Bootstraps the database with a PMO team, a BGV team and a demo employee so
the application can be exercised immediately after a fresh install.

Run with:  python -m scripts.seed
"""
from datetime import datetime, timedelta, timezone

from app.core.config import get_settings
from app.core.database import SessionLocal, init_db
from app.core.logging_config import get_logger
from app.models.entities import (
    BackgroundVerificationTeam,
    Employee,
    PMOTeam,
)

logger = get_logger(__name__)


def seed() -> None:
    settings = get_settings()
    db = SessionLocal()
    try:
        if db.query(PMOTeam).first() is None:
            db.add(
                PMOTeam(
                    pmo_team_name="Juniper PMO Team",
                    pmo_email_id=settings.pmo_team_email,
                    reviewer_name="PMO Reviewer",
                )
            )
            logger.info("Seeded PMO team.")

        if db.query(BackgroundVerificationTeam).first() is None:
            db.add(
                BackgroundVerificationTeam(
                    bv_team_name="Background Verification Team",
                    bv_email_id=settings.bgv_team_email,
                )
            )
            logger.info("Seeded BGV team.")

        demo_talent_id = "DEMO001"
        if db.query(Employee).filter(Employee.talent_id == demo_talent_id).first() is None:
            demo_email = "demo.employee@example.com"
            db.add(
                Employee(
                    talent_id=demo_talent_id,
                    employee_name="Demo Employee",
                    project_id="PROJ-DEMO-001",
                    account_focal_email="account.focal@example.com",
                    emp_type="Full Time",
                    account_name="Demo Account",
                    project_name="Demo Project",
                    project_dept_code="DEPT-001",
                    account_id="ACC-001",
                    dou_number="DOU-001",
                    date_requested=datetime.now(timezone.utc),
                    email=demo_email,
                    phone="+91 90000 00000",
                    department="Engineering",
                    designation="Software Engineer",
                    joining_date=datetime.now(timezone.utc) + timedelta(days=14),
                )
            )
            logger.info("Seeded demo employee (%s).", demo_email)

        db.commit()
        logger.info("Seed complete.")
    finally:
        db.close()


if __name__ == "__main__":
    seed()
