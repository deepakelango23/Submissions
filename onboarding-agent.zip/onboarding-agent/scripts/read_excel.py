import pandas as pd
import sys

try:
    df = pd.read_excel('data/onboarding_template.xlsx')
    print("Excel file columns:")
    print(df.columns.tolist())
    print("\nFirst few rows:")
    print(df.head())
    print("\nData types:")
    print(df.dtypes)
except Exception as e:
    print(f"Error reading Excel: {e}")
    sys.exit(1)

# Made with Bob
