"""Combined reset and seed script."""
import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from datetime import datetime, timedelta, timezone

from app.core.config import get_settings
from app.core.database import Base, SessionLocal, engine
from app.core.logging_config import get_logger
from app.models.entities import (
    BackgroundVerificationTeam,
    Employee,
    PMOTeam,
)

logger = get_logger(__name__)


def reset_and_seed():
    """Drop all tables, recreate with new schema, and seed data."""
    try:
        # Step 1: Drop all tables
        logger.info("Dropping all existing tables...")
        Base.metadata.drop_all(bind=engine)
        logger.info("All tables dropped successfully")
        
        # Step 2: Create tables with new schema
        logger.info("Creating tables with new schema...")
        Base.metadata.create_all(bind=engine)
        logger.info("All tables created successfully")
        
        # Step 3: Seed data
        logger.info("Seeding database...")
        settings = get_settings()
        db = SessionLocal()
        
        try:
            # Seed PMO team
            if db.query(PMOTeam).first() is None:
                db.add(
                    PMOTeam(
                        pmo_team_name="Juniper PMO Team",
                        pmo_email_id=settings.pmo_team_email,
                        reviewer_name="PMO Reviewer",
                    )
                )
                logger.info("Seeded PMO team.")

            # Seed BGV team
            if db.query(BackgroundVerificationTeam).first() is None:
                db.add(
                    BackgroundVerificationTeam(
                        bv_team_name="Background Verification Team",
                        bv_email_id=settings.bgv_team_email,
                    )
                )
                logger.info("Seeded BGV team.")

            # Seed demo employee
            demo_talent_id = "DEMO001"
            if db.query(Employee).filter(Employee.talent_id == demo_talent_id).first() is None:
                demo_email = "demo.employee@example.com"
                db.add(
                    Employee(
                        talent_id=demo_talent_id,
                        employee_name="Demo Employee",
                        project_id="PROJ-DEMO-001",
                        account_focal_email="account.focal@example.com",
                        emp_type="Full Time",
                        account_name="Demo Account",
                        project_name="Demo Project",
                        project_dept_code="DEPT-001",
                        account_id="ACC-001",
                        dou_number="DOU-001",
                        date_requested=datetime.now(timezone.utc),
                        email=demo_email,
                        phone="+91 90000 00000",
                        department="Engineering",
                        designation="Software Engineer",
                        joining_date=datetime.now(timezone.utc) + timedelta(days=14),
                    )
                )
                logger.info("Seeded demo employee (%s).", demo_email)

            db.commit()
            logger.info("Seed complete.")
            logger.info("=" * 50)
            logger.info("Database reset and seed successful!")
            logger.info("=" * 50)
            return True
        finally:
            db.close()
            
    except Exception as e:
        logger.error(f"Error during reset and seed: {e}")
        return False


if __name__ == "__main__":
    success = reset_and_seed()
    sys.exit(0 if success else 1)

# Made with Bob
