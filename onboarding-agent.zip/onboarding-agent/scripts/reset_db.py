"""Reset database script - drops all tables and recreates with new schema."""
import os
import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from app.core.database import Base, engine
from app.core.logging_config import get_logger

logger = get_logger(__name__)


def reset_database():
    """Drop all tables and recreate them with the current schema."""
    try:
        logger.info("Dropping all existing tables...")
        Base.metadata.drop_all(bind=engine)
        logger.info("All tables dropped successfully")
        
        logger.info("Creating tables with new schema...")
        Base.metadata.create_all(bind=engine)
        logger.info("All tables created successfully")
        
        logger.info("Database reset complete!")
        return True
    except Exception as e:
        logger.error(f"Error resetting database: {e}")
        return False


if __name__ == "__main__":
    success = reset_database()
    sys.exit(0 if success else 1)

# Made with Bob
